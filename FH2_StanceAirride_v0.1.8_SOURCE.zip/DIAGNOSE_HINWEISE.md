# v0.1.7 – read-only Springs-Diagnose (Quellcode)

Dies ist KEINE bestätigte Reparatur der erweiterten Federhöhe.

## Nachweis
- v0.1.6-Log meldet Loader 24-mal vor dem Öffnen der Springs-Seite und nur die Änderung des 25. Datensatzes.
- v5.65-DLL enthält ältere STANCE_GLOBAL_V562-/STANCE_STARTUP_V560-Protokolltexte, die eine andere, teils globale Strategie belegen. Welcher Zweig in v5.65 tatsächlich aktiv ist, ist allein aus diesen Strings nicht feststellbar.
- Diese Variante protokolliert ausschließlich, wie viele gültige Federdatensätze VOR dem Öffnen des Menüs gelesen werden. **Kein zusätzlicher Schreibzugriff** auf die Spieldaten. Bestehende Airride- und Foto-Logik bleibt unverändert.

## Verwendung
Unter Windows mit Zig 0.15.2 `BUILD_WINDOWS.cmd` aufrufen (oder zig.exe auf die CMD-Datei ziehen); anschließend die neue StanceAirride.dll testweise in `fh2-mods` ersetzen. Vorher alte DLL sichern. Spiel starten, Fahrwerk/Federn öffnen und `platform.log` auslesen.

Wichtige Logzeilen: `DIAG: FRONT eligible rows before page` und `DIAG: REAR eligible rows before page`.

Der Fix wird erst nach Auswertung dieser Zahlen gezielt entwickelt; niemals als globale Schreiboperation ohne Fahrzeugzuordnung.
