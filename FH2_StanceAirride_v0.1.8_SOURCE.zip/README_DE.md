# FH2 Stance & Airride – FH2 Mod Platform v0.1.8, Legacy Springs BETA

**Fokus:** Wiederherstellung der erweiterten nativen Federhöhen-Regler (-3 cm / +5 cm) auf Basis der alten v5.65-DLL. **Nicht im Spiel bestätigt.**

- Unverändert: Airride und Fotomodus, Stance-Slider, Camber, Spur, Szenen- und Fahrzeugwechsel, Profilverwaltung.
- Geändert: Nur `src/stance_spring_bounds_platform.c`, neue Rechenfunktion `vendor/stance_spring_bounds_v565.h`, Versionskennung und Paketname.
- Die v5.65-Binärdatei enthält die Modi `STANCE_GLOBAL_V562` (alle gültigen nativen Zeilen) und `STANCE_STARTUP_V560` (frühe Zeilen). Hier wird die **globale Loader-Strategie** übernommen: Bereits vor Öffnen der Tuning-Seite geladene Federdatensätze erhalten die Bereichserweiterung.
- Mathematik: Ursprüngliche fünf Float-Felder am nativen Federdatensatz bleiben Basis; DefaultRideHeight, Compression und Stretch bleiben unverändert. Nur Min/Max werden angepasst; Sicherheitsgrenzen begrenzen die Zusätze.
- Korrektur zur alten v5.56-Gültigkeitsprüfung: Der Default-Wert darf exakt auf Min oder Max liegen.
- Hook-Adressen/Signaturen sowie FH2-Mod-Platform-API bleiben unverändert. Kein `winmm.dll`-Ersatz.

## WICHTIG: Global-Modus / Kompatibilität

Die alte v5.65 bezeichnete dieses Verfahren selbst als **`PLAYER_OWNERSHIP_NOT_PROVEN`** und warnte: **`MAY ALTER AI/TRAFFIC VEHICLES`**. Es kann die Federhöhen-Grenzen auch von NPCs, Verkehr oder anderen geladenen Fahrzeugen ändern. **Nur offline, nicht im Multiplayer verwenden; Spielstände und DLL sichern.** Wer diese Auswirkungen vermeiden will, setzt in `StanceAirride/StanceAirride.ini` unter `[General]` `spring_bounds_extension=0` oder verwendet die letzte stabile v0.1.6.

## Installation

Unter Windows mit Zig 0.15.2 die `zig.exe` auf `BUILD_WINDOWS.cmd` ziehen. Der Build legt eine Plugin-DLL unter `dist\StanceAirride.dll` und ein Installations-ZIP unter `dist` ab. Nur `fh2-mods\StanceAirride.dll` ersetzen. Vorher alte DLL sichern. **Quellcode nicht in D:\xboxone entpacken.** Alle anderen DLLs und INI-Dateien unangetastet lassen.

## Prüfung

1. Offline in Freeroam starten, noch ohne Tuning-Menü.
2. Fahrwerks- und Federhöhe-Menü öffnen. Die normale Höhenverstellung sollte jetzt mehr Spielraum besitzen. Keine Änderungen speichern, bevor die Anzeige geprüft wurde.
3. `fh2-mods/platform.log` überprüfen: `0.1.8-v565-legacy-springs-beta` und `Spring V565`-Meldungen.
4. An mehreren Fahrzeugen im Stand testen; Airride-Fotomodus prüfen.

## Technischer Status

Es liegt nur die **alte v5.65-DLL**, nicht deren Quellcode vor. Der neue C-Code ist deshalb ein nachvollziehbarer, getesteter Port der in der DLL erkennbaren Legacy-Strategie, **keine nachweislich bytegleiche Kopie**. Lokale Unit-Tests können die Wirkung im Spiel nicht bestätigen. Falls der UI-Regler unverändert bleibt, müssen wir die tatsächliche UI-Bindung weiter untersuchen.

## Englische Menübeschriftung (UI-Only)

Dieser Fork stellt **alle von unserem Plugin ergänzten sichtbaren Beschriftungen** auf Englisch. Originale Forza-Menütexte stammen weiterhin aus dem Spiel. Keine Änderungen an Airride-/Federhöhenlogik, siehe `ENGLISH_MENU_NOTES.md`.
