FH2 StanceAirride / FH2 Mod Platform v0.1.8 v5.65-Legacy-Springs BETA

OFFLINE ONLY. Legacy global native loader can affect AI/traffic Spring ranges.
No in-game validation yet. Keep a backup.

1) Game/Azimuth close.
2) Backup D:\xboxone\fh2-mods\StanceAirride.dll in a folder OUTSIDE fh2-mods.
3) Compile the separate source folder with Zig 0.15.2 and BUILD_WINDOWS.cmd.
4) Replace ONLY fh2-mods\StanceAirride.dll with dist\StanceAirride.dll.
5) Keep all existing INIs and other DLLs unchanged.
6) Launch offline. Test Spring height range and Photo Airride.
7) If in doubt: restore v0.1.6. To disable global Spring mode use
   [General] spring_bounds_extension=0 in StanceAirride\StanceAirride.ini.

The compiled DLL imports neither the CRT nor InterlockedCompareExchange (checked by build script).
