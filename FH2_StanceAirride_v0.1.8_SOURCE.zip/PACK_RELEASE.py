#!/usr/bin/env python3
"""Package only the new standalone DLL. NEVER package Azimuth/Extra Options or platform loaders."""
import sys
import zipfile
from pathlib import Path

root = Path(__file__).resolve().parent
if len(sys.argv) != 2:
    raise SystemExit("Usage: python PACK_RELEASE.py dist\\StanceAirride.dll")
file = (root / sys.argv[1]).resolve()
if file.name.casefold() != "stanceairride.dll" or not file.is_file() or not file.is_relative_to(root):
    raise SystemExit("Refusing input: expected a built StanceAirride.dll under this project")
data = file.read_bytes()
if not data.startswith(b"MZ") or len(data) < 4096:
    raise SystemExit("Not a compiled Windows DLL, refusing to create release")
import subprocess
subprocess.check_call([sys.executable, str(root / "tests" / "verify_plugin_dll.py"), str(file)])
out = root / "dist" / "StanceAirride_FH2ModPlatform_v0.1.8_FINAL_MENU_TEXT_INSTALL.zip"
with zipfile.ZipFile(out, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
    z.write(file, "fh2-mods/StanceAirride.dll")
    z.write(root / "StanceAirride" / "Profiles.ini.example", "StanceAirride/Profiles.ini.example")
    z.write(root / "StanceAirride" / "StanceAirride.ini.example", "StanceAirride/StanceAirride.ini.example")
    z.write(root / "README_INSTALL.txt", "StanceAirride/README_INSTALL.txt")
    z.write(root / "LICENSE-GPL-3.0.txt", "StanceAirride/LICENSE-GPL-3.0.txt")
    z.write(root / "LICENSE-FH2ModPlatform-MIT.txt", "StanceAirride/LICENSE-FH2ModPlatform-MIT.txt")
with zipfile.ZipFile(out) as z:
    assert z.testzip() is None
    paths = {n.lower() for n in z.namelist()}
    assert "fh2-mods/stanceairride.dll" in paths
    assert all(not any(x in n for x in ("winmm.dll", "azimuth-tls.dll", "d3dcompiler_47.dll", "azimuth.exe")) for n in paths)
print("INSTALL ZIP CREATED:", out)
print("No existing Azimuth, Extra Options or platform loader DLLs packaged.")
