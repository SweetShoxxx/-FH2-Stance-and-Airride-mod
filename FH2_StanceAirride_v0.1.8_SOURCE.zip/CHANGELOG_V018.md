# Änderungen v0.1.8 (nur Federhöhen-Port)

- Entfernt: v0.1.6/0.1.7 „erstes gültiges Row NACH dem Öffnen der Tuning-Seite“-Gate.
- Neu: Anwendung an ALLEN gültigen nativen Federdatensätzen schon beim Loader-Aufruf (v5.65-Modus `STANCE_GLOBAL_V562`), auch VOR der UI. Diagnose v0.1.7 zeigte 2 geeignete frühe Rows pro Achse.
- Neue Validierung: Gleichheit Default==Min/Max zulässig (Fix für alte v5.56-Randlage).
- Maximal -3/+5 cm; Compression/Stretch-Kappen wie zuvor. Native Standardhöhe bleibt unverändert.
- Readback nach jedem Schreibvorgang und Rollback bei Abweichung.
- Getrennte Plattform-Hooks und unveränderte Airride/Fotomodus-Funktionen.

Risiko: Old v5.65 global mode had NO player ownership. Änderungen können auch AI/Traffic betreffen. Experimentelle Offline-Beta, kein im Spiel nachgewiesener Fix.
