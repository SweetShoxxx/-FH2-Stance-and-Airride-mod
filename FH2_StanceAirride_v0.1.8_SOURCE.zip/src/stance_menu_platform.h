#ifndef STANCE_MENU_PLATFORM_H
#define STANCE_MENU_PLATFORM_H
#include <stdint.h>
#include <wchar.h>
#include <stddef.h>
#include "fh2mod_api3_subset.h"
#include "stance_profile_values.h"
/* Optional native UI bridge. Owns NO Azimuth or Extra Options files. */
int sap_menu_install(const FH2ModApi *,FH2Mod *,unsigned char *image,
                    const wchar_t *profiles,const wchar_t *config);
/* Callback returns 1 only for a freshly verified current player car. */
void sap_menu_set_player_sync(int (*callback)(void));
void sap_menu_select(uint32_t model,const StanceProfileValues *,int photo_enabled);
void sap_menu_get(StanceProfileValues *out,int *photo_drop_cm);
#endif
