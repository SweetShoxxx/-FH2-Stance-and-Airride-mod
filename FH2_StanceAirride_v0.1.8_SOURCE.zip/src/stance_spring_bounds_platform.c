/* GPL-3.0. FH2 v5.65-inspired native Springs range for FH2 Mod Platform.
 * Port of the legacy STANCE_GLOBAL_V562 strategy: process EACH validated
 * row at its native loader call, including rows loaded BEFORE opening the UI.
 * The old binary warns: PLAYER_OWNERSHIP_NOT_PROVEN / MAY ALTER AI/TRAFFIC.
 * Experimental OFFLINE testing ONLY; disable with spring_bounds_extension=0.
 * Existing Stance, Airride, Photo and vehicle lifecycle code is untouched. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "stance_atomic_intrinsics.h"
#include <stdint.h>
#include <stddef.h>
#include "stance_spring_bounds_platform.h"
#include "stance_spring_bounds_v565.h"

#define RVA_FRONT 0x0106155Fu
#define RVA_REAR  0x010616D5u
static const FH2ModApi *platform;
static FH2Mod *owner;
static volatile LONG seen[2],qualified[2],changed[2],clamped[2],failed[2];
static volatile LONG ui_page_count, player_model;
typedef uintptr_t (*NativeRowFn)(void*,void*,void*);
static NativeRowFn original_front,original_rear;
static void log_line(const char *s){if(platform&&owner)platform->log(owner,s);}
static void stat(const char *name,LONG value){
    char out[160];size_t n=0;
    while(name[n]&&n+3<sizeof(out)){out[n]=name[n];n++;}
    if(name[n])return;
    out[n++]='=';
    unsigned v=(unsigned)(value<0?-(value+1)+1:value);char rev[16];unsigned r=0;
    do{rev[r++]=(char)('0'+v%10u);v/=10u;}while(v&&r<sizeof(rev));
    if(value<0)out[n++]='-';
    while(r)out[n++]=rev[--r];
    out[n]=0;log_line(out);
}
static int accessible(const void *p,size_t n,int write){
    MEMORY_BASIC_INFORMATION m;
    if(!p||!n||!VirtualQuery(p,&m,sizeof(m))||m.State!=MEM_COMMIT||
       (m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return 0;
    uintptr_t a=(uintptr_t)p,b=(uintptr_t)m.BaseAddress+m.RegionSize;
    if(a>UINTPTR_MAX-n||a+n>b||b<a)return 0;
    DWORD v=m.Protect&0xff;
    if(write)return v==PAGE_READWRITE||v==PAGE_WRITECOPY||v==PAGE_EXECUTE_READWRITE||v==PAGE_EXECUTE_WRITECOPY;
    return v==PAGE_READONLY||v==PAGE_READWRITE||v==PAGE_WRITECOPY||v==PAGE_EXECUTE_READ||v==PAGE_EXECUTE_READWRITE||v==PAGE_EXECUTE_WRITECOPY;
}
static void read_float_bytes(float *out,const volatile unsigned char *p){
    volatile unsigned char *dest=(volatile unsigned char*)out;
    for(size_t i=0;i<sizeof(float);i++)dest[i]=p[i];
}
static void write_float_bytes(volatile unsigned char *p,const float *v){
    const volatile unsigned char *src=(const volatile unsigned char*)v;
    for(size_t i=0;i<sizeof(float);i++)p[i]=src[i];
}
void sap_bounds_observe_player(void *car,void *body,uint32_t model){
    (void)car;(void)body;
    /* Ownership is not used by v5.65's global loader strategy.
       Keep the API signature to preserve the established Airride caller. */
    sa_xchg32(&player_model,model<1000000u?(LONG)model:0);
}
void sap_bounds_note_tuning_page(uint32_t model){
    (void)model;
    if(sa_inc32(&ui_page_count)>8)return;
    stat("StanceAirride Springs V565: FRONT rows loaded",sa_cmpxchg32(&seen[0],0,0));
    stat("StanceAirride Springs V565: REAR rows loaded",sa_cmpxchg32(&seen[1],0,0));
    stat("StanceAirride Springs V565: FRONT rows eligible",sa_cmpxchg32(&qualified[0],0,0));
    stat("StanceAirride Springs V565: REAR rows eligible",sa_cmpxchg32(&qualified[1],0,0));
    stat("StanceAirride Springs V565: FRONT range writes",sa_cmpxchg32(&changed[0],0,0));
    stat("StanceAirride Springs V565: REAR range writes",sa_cmpxchg32(&changed[1],0,0));
}
static uintptr_t row_hook(int axis,NativeRowFn original,void *out,void *metadata,void *reader){
    if(!original)return 0;
    /* Preserve original game loader and its return value exactly. */
    uintptr_t result=original(out,metadata,reader);
    sa_inc32(&seen[axis]);
    if(!result||!out)return result;
    volatile unsigned char *row=(volatile unsigned char*)out;
    if(!accessible((const void*)(row+0x0c),5*sizeof(float),0))return result;
    float h[5];for(int i=0;i<5;i++)read_float_bytes(&h[i],row+0x0c+4*i);
    float mn=0.f,mx=0.f;int ls=0,hs=0;
    if(!fh2_v565_calculate(h,&mn,&mx,&ls,&hs))return result;
    sa_inc32(&qualified[axis]);
    /* Do not touch DefaultRideHeight, compression/stretch or anything else. */
    if(!accessible((const void*)(row+0x10),sizeof(float)*2,1)){
        sa_inc32(&failed[axis]);return result;
    }
    const float orig_min=h[1],orig_max=h[2];
    if(ls!=FH2_V565_SKIP)write_float_bytes(row+0x10,&mn);
    if(hs!=FH2_V565_SKIP)write_float_bytes(row+0x14,&mx);
    float check_min,check_max;
    read_float_bytes(&check_min,row+0x10);
    read_float_bytes(&check_max,row+0x14);
    if(check_min!=(ls==FH2_V565_SKIP?orig_min:mn) ||
       check_max!=(hs==FH2_V565_SKIP?orig_max:mx)){
        /* On readback mismatch, restore both native values. */
        write_float_bytes(row+0x10,&orig_min);
        write_float_bytes(row+0x14,&orig_max);
        sa_inc32(&failed[axis]);
        log_line("StanceAirride Springs V565: failed readback, limits restored");
        return result;
    }
    if(ls==FH2_V565_CLAMPED||hs==FH2_V565_CLAMPED)sa_inc32(&clamped[axis]);
    LONG count=sa_inc32(&changed[axis]);
    if(count==1){
        log_line(axis==0?
          "StanceAirride Springs V565: FRONT first eligible row patched at native load":
          "StanceAirride Springs V565: REAR first eligible row patched at native load");
    }
    return result;
}
static uintptr_t front(void *out,void *meta,void *reader){return row_hook(0,original_front,out,meta,reader);}
static uintptr_t rear(void *out,void *meta,void *reader){return row_hook(1,original_rear,out,meta,reader);}
int sap_bounds_install(const FH2ModApi *api,FH2Mod *m,unsigned char *img){
    static const unsigned char front_sig[5]={0xe8,0xac,0x02,0x00,0x00};
    static const unsigned char rear_sig[5]={0xe8,0x36,0x01,0x00,0x00};
    if(!api||!m||!img||!api->hook_call||!api->enable_hooks||
       !accessible(img+RVA_FRONT,5,0)||!accessible(img+RVA_REAR,5,0))return 0;
    for(int i=0;i<5;i++)if(img[RVA_FRONT+i]!=front_sig[i]||img[RVA_REAR+i]!=rear_sig[i]){
        api->log(m,"StanceAirride: native Spring callsites differ; extension disabled");return 0;
    }
    platform=api;owner=m;
    FH2Hook *fh=api->hook_call(m,"V565 FRONT global native Springs",img+RVA_FRONT,(void*)front,(void**)&original_front);
    FH2Hook *rh=api->hook_call(m,"V565 REAR global native Springs",img+RVA_REAR,(void*)rear,(void**)&original_rear);
    if(!fh||!rh){log_line("StanceAirride Springs V565: hook conflict; no bounds changes");return 0;}
    if(!api->enable_hooks(m,fh)||!api->enable_hooks(m,rh)){
        api->disable_hooks(m,fh);api->disable_hooks(m,rh);
        log_line("StanceAirride Springs V565: hook enabling failed");return 0;
    }
    log_line("StanceAirride Springs V565: GLOBAL legacy range active (-3/+5cm), BEFORE tuning UI");
    log_line("StanceAirride Springs V565: OFFLINE ONLY, ownership NOT PROVEN; may affect AI/traffic");
    return 1;
}
