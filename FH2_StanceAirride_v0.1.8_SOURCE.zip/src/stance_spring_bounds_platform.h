#ifndef FH2_STANCE_BOUNDS_PLATFORM_H
#define FH2_STANCE_BOUNDS_PLATFORM_H
#include <stdint.h>
#include "fh2mod_api3_subset.h"
/* Experimental port of v5.65 legacy global Springs row loader behavior.
   Global range modification is NOT player-owned: test offline only.
   Does not replace Azimuth DLLs, no raw pointer scans or persistent data writes. */
int sap_bounds_install(const FH2ModApi *api,FH2Mod *mod,unsigned char *image);
void sap_bounds_observe_player(void *car,void *body,uint32_t model);
void sap_bounds_note_tuning_page(uint32_t model);
#endif
