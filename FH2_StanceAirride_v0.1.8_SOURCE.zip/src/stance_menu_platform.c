/* Platform-managed native Springs XAML extension derived from the earlier
   GPLv3 Stance v5.65 implementation. Keeps the original Springs UI intact.
   No static EXE patches or winmm/azimuth-tls replacement. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "stance_atomic_intrinsics.h"
#include <stddef.h>
#include <stdint.h>
#include "stance_menu_platform.h"
#include "stance_spring_bounds_platform.h"
#include "stance_springs_preview.h"

#define NATIVE_GET_RESOURCE       0x00AABEC0u
#define NATIVE_TUNING_TYPE       0x00E98E10u
#define NATIVE_REGISTRY          0x03540E40u
#define NATIVE_REGISTER         0x0155EE30u
#define NATIVE_FLOAT_FACTORY    0x00ED6E90u
#define NATIVE_INIT             0x0143EB80u
#define NATIVE_CLEANUP          0x01442050u
#define NATIVE_ALLOC            0x003229C0u
#define NATIVE_FREE             0x0031C7B0u
#define NATIVE_DELETE           0x00257730u
#define NATIVE_BOX_FLOAT        0x003F5990u
#define NATIVE_PROPERTY_CHANGED 0x00CF9C60u
#define MAX_XAML 262144u

static const FH2ModApi *bridge_api;
static FH2Mod *bridge_mod;
static unsigned char *game;
static wchar_t profile_path[MAX_PATH], config_path[MAX_PATH];
static volatile LONG binding_state; /* 0 = uninitialized; 1 = initializing; 2 = ready */
static volatile LONG xaml_count, property_change_count;
static void report(const char *text);
static uint32_t model_id;
static int (*verify_and_sync_player)(void);
static volatile LONG failed_player_sync_logged;
void sap_menu_set_player_sync(int (*callback)(void)){
    verify_and_sync_player=callback;
}
static int update_menu_player(void){
    if(!verify_and_sync_player || !verify_and_sync_player()){
        if(sa_cmpxchg32(&failed_player_sync_logged,1,0)==0)
            report("StanceAirride: player not verified in current tuning context; menu writes blocked");
        return 0;
    }
    sa_xchg32(&failed_player_sync_logged,0);
    return 1;
}
static StanceProfileValues values;
static int allow_photo;
static int selected_photo_drop=3;

typedef struct {
    void **vtable;
    unsigned char header[0x20];
    void *getter,*setter,*unused;
    const char *name;
    void *type;
    uint64_t flags;
} NativeProperty;
_Static_assert(sizeof(NativeProperty)==0x58,"native property layout");
typedef struct NativePropertyLink {NativeProperty *property; struct NativePropertyLink *next;} NativePropertyLink;
typedef struct {
    void **vtable;
    unsigned char header[0x20];
    char *bytes;
    int length,capacity;
} NativeResource;
_Static_assert(offsetof(NativeResource,bytes)==0x28,"native resource buffer");
static NativeProperty properties[5];
static NativePropertyLink links[5];
static void *resource_vtable[7];
static void **(*real_resource)(void*,void**);
static const char *const property_names[5]={
 "StanceFrontCamber","StanceRearCamber","StanceFrontTrack","StanceRearTrack", "AirridePhotoDepthCm"
};
static const wchar_t *const profile_keys[4]={
 L"front_camber_tenths",L"rear_camber_tenths",L"front_track_mm",L"rear_track_mm"
};

static void report(const char *s){if(bridge_api&&bridge_mod)bridge_api->log(bridge_mod,s);}
static int mapped(const void *p,size_t n,int writable){
    MEMORY_BASIC_INFORMATION m;
    if(!p||!n||n>MAX_XAML||!VirtualQuery(p,&m,sizeof m))return 0;
    if(m.State!=MEM_COMMIT||(m.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return 0;
    uintptr_t a=(uintptr_t)p,e=(uintptr_t)m.BaseAddress+m.RegionSize;
    if(a>UINTPTR_MAX-n||a+n>e)return 0;
    DWORD prot=m.Protect&0xff;
    if(writable)return prot==PAGE_READWRITE||prot==PAGE_WRITECOPY||prot==PAGE_EXECUTE_READWRITE||prot==PAGE_EXECUTE_WRITECOPY;
    return prot==PAGE_READONLY||prot==PAGE_READWRITE||prot==PAGE_WRITECOPY||prot==PAGE_EXECUTE_READ||prot==PAGE_EXECUTE_READWRITE||prot==PAGE_EXECUTE_WRITECOPY;
}
static void bytes_copy(void *d,const void *s,size_t n){
    volatile unsigned char *a=(volatile unsigned char*)d;
    const volatile unsigned char *b=(const volatile unsigned char*)s;
    for(size_t i=0;i<n;i++)a[i]=b[i];
}
static int bytes_eq(const void *a,const void *b,size_t n){
    const volatile unsigned char *p=(const volatile unsigned char*)a,*q=(const volatile unsigned char*)b;
    for(size_t i=0;i<n;i++)if(p[i]!=q[i])return 0;
    return 1;
}
static int text_has(const char *s,size_t n,const char *needle){
    size_t k=0;while(needle[k])k++;
    if(n<k)return 0;
    for(size_t i=0;i+k<=n;i++){
        size_t j=0;while(j<k&&s[i+j]==needle[j])j++;
        if(j==k)return 1;
    }
    return 0;
}
static void wide_int(int value,wchar_t out[20]){
    unsigned mag=value<0?(unsigned)(-(value+1))+1u:(unsigned)value;
    wchar_t tmp[16];unsigned n=0,i=0;
    do{tmp[n++]=(wchar_t)(L'0'+mag%10u);mag/=10u;}while(mag&&n<16);
    if(value<0)out[i++]=L'-';
    while(n)out[i++]=tmp[--n];out[i]=0;
}
static int section(uint32_t id,wchar_t out[32]){
    if(!id)return 0;
    const wchar_t pre[]=L"model_";unsigned i=0;
    for(unsigned j=0;j<6;j++)out[i++]=pre[j];
    wchar_t tmp[16];unsigned n=0;
    do{tmp[n++]=(wchar_t)(L'0'+id%10u);id/=10u;}while(id&&n<16);
    if(i+n>=32)return 0;
    while(n)out[i++]=tmp[--n];out[i]=0;return 1;
}
static int32_t *field(StanceProfileValues *p,int index){
    switch(index){
    case 0:return &p->front_camber_tenths;
    case 1:return &p->rear_camber_tenths;
    case 2:return &p->front_track_mm;
    case 3:return &p->rear_track_mm;
    default:return NULL;
    }
}
static int prop_index(const NativeProperty *p){
    uintptr_t at=(uintptr_t)p,first=(uintptr_t)properties;
    if(at<first||at>=first+sizeof properties||(at-first)%sizeof properties[0])return -1;
    return (int)((at-first)/sizeof properties[0]);
}
static int read_drop(void){
    wchar_t s[32];if(!section(model_id,s))return 3;
    int fallback=GetPrivateProfileIntW(L"Airride",L"drop_cm",3,config_path);
    int v=GetPrivateProfileIntW(s,L"photo_drop_cm",fallback,config_path);
    return v>=2&&v<=5?v:3;
}
static void **get_prop(void **ret,NativeProperty *p,void *vm){
    (void)vm;
    if(!ret)return ret;
    *ret=NULL;
    if(!update_menu_player())return ret;
    int ix=prop_index(p);
    if(ix<0||!game)return ret;
    float v=0;
    if(ix==4)v=(float)selected_photo_drop;
    else if(model_id){int32_t *f=field(&values,ix);if(f)v=(float)*f*(ix<2?0.1f:1.f);}
    ((void **(*)(void **,const void *))(game+NATIVE_BOX_FLOAT))(ret,&v);
    return ret;
}
static void set_prop(NativeProperty *p,void *vm,void *boxed){
    /* Never write using a model_id cached from the previous car. */
    if(!update_menu_player())return;
    int ix=prop_index(p);
    if(ix<0||!model_id||!game||!vm||!mapped(boxed,0x2cu,0))return;
    float requested=0;
    bytes_copy(&requested,(unsigned char*)boxed+0x28,sizeof requested);
    if(!(requested>=-150.f&&requested<=100.f))return;/* NaN rejected */
    wchar_t sec[32],num[20];
    if(!section(model_id,sec))return;
    int new_val=(int)(requested*(ix<2?10.f:1.f)+(requested<0.f?-0.5f:0.5f));
    if(ix==4){
        if(new_val<2||new_val>5||new_val==selected_photo_drop)return;
        wide_int(new_val,num);
        if(!WritePrivateProfileStringW(sec,L"photo_drop_cm",num,config_path))return;
        selected_photo_drop=new_val;
    }else{
        StanceProfileValues candidate=values;
        int32_t *slot=field(&candidate,ix);
        if(!slot||*slot==new_val)return;
        *slot=new_val;
        if(!stance_profile_values_valid(&candidate))return;
        wide_int(new_val,num);
        if(!WritePrivateProfileStringW(sec,profile_keys[ix],num,profile_path))return;
        values=candidate;
    }
    sa_inc32(&property_change_count);
    ((void (*)(void*,void*))(game+NATIVE_PROPERTY_CHANGED))(vm,p);
}
static int register_bindings(void){
    static const unsigned char head[]={0x40,0x53,0x48,0x81,0xec,0xd0,0x00,0x00,0x00};
    LONG st=sa_cmpxchg32(&binding_state,1,0);
    if(st==2)return 1;
    if(st!=0)return 0;
    if(!mapped(game+NATIVE_TUNING_TYPE,sizeof head,0)||
       !bytes_eq(game+NATIVE_TUNING_TYPE,head,sizeof head))goto fail;
    ((void (*)(void))(game+NATIVE_TUNING_TYPE))();
    NativeProperty *template=((NativeProperty *(*)(void))(game+NATIVE_FLOAT_FACTORY))();
    if(!mapped(template,sizeof(NativeProperty),0))goto fail;
    for(int i=0;i<5;i++){
        NativeProperty *p=&properties[i];
        ((void (*)(void*))(game+NATIVE_INIT))(p);
        p->vtable=template->vtable;
        bytes_copy((unsigned char*)p+0x28,(unsigned char*)template+0x28,0x30);
        p->name=property_names[i];p->getter=(void*)get_prop;p->setter=(void*)set_prop;
        links[i].property=p;links[i].next=NULL;
        ((void (*)(void*,NativePropertyLink*))(game+NATIVE_REGISTER))(
            game+NATIVE_REGISTRY,&links[i]);
    }
    sa_xchg32(&binding_state,2);
    report("StanceAirride: native Springs slider properties registered (5)");
    return 1;
fail:
    sa_xchg32(&binding_state,0);
    report("StanceAirride: native tuning property registration unavailable; unchanged Springs UI");
    return 0;
}
static void *release_resource(NativeResource *resource,unsigned flags){
    ((void (*)(void*))(game+NATIVE_CLEANUP))(resource);
    if(flags&1)((void (*)(void*))(game+NATIVE_FREE))(resource);
    return resource;
}
static void release_ref(NativeResource *r){
    if(!r)return;
    if(sa_dec32((volatile LONG*)((unsigned char*)r+0x10))==0)
        ((void (*)(void*))(game+NATIVE_DELETE))(r);
}
static void **resource_hook(void *reader,void **output){
    if(!real_resource)return output;
    real_resource(reader,output);
    NativeResource *old=output?(NativeResource*)*output:NULL;
    if(!old||!mapped(old,sizeof(NativeResource),0)||old->length<=0||
       old->length>(int)MAX_XAML||!mapped(old->bytes,(size_t)old->length,0) ||
       !text_has(old->bytes,(size_t)old->length,
          "x:Class=\"ForzaUI.Scenes.Anthem.A_TuningOptions\""))return output;
    if(!text_has(old->bytes,(size_t)old->length,"<local:CommonListBox x:Name=\"StackPanel_5_Springs\""))return output;
    /* A newly selected vehicle may not have emitted a native car tick yet. */
    const int current_id_verified = update_menu_player();
    if(text_has(old->bytes,(size_t)old->length,"FH2_STANCE_PROFILE_BINDING_V19"))return output;
    if(!register_bindings())return output;
    size_t cap=(size_t)old->length+16384u;
    NativeResource *r=((void *(*)(size_t))(game+NATIVE_ALLOC))(sizeof(NativeResource)+cap);
    if(!r||!mapped(r,sizeof(NativeResource)+cap,1))return output;
    int vals[6]={values.front_camber_tenths,values.rear_camber_tenths,
      values.front_height_mm,values.rear_height_mm,values.front_track_mm,values.rear_track_mm};
    char *dst=(char*)(r+1);
    size_t len=stance_springs_preview_xaml(old->bytes,(size_t)old->length,
                           dst,cap,vals,model_id,allow_photo,current_id_verified);
    if(!len||len>cap){((void (*)(void*))(game+NATIVE_FREE))(r);return output;}
    if(!mapped(old->vtable-1,sizeof resource_vtable,0)){
        ((void (*)(void*))(game+NATIVE_FREE))(r);return output;
    }
    ((void (*)(void*))(game+NATIVE_INIT))(r);
    bytes_copy(resource_vtable,old->vtable-1,sizeof resource_vtable);
    resource_vtable[1]=(void*)release_resource;
    r->vtable=resource_vtable+1;
    r->bytes=dst;r->length=(int)len;r->capacity=(int)cap;
    *output=r;
    release_ref(old);
    sap_bounds_note_tuning_page(model_id);
    if(sa_inc32(&xaml_count)<=6)
       report("StanceAirride: Springs XAML augmented, original tuning controls kept");
    return output;
}
void sap_menu_select(uint32_t model,const StanceProfileValues *profile,int photo){
    model_id=model;
    allow_photo=photo;
    if(profile)values=*profile;
    selected_photo_drop=read_drop();
}
void sap_menu_get(StanceProfileValues *out,int *drop){
    if(out)*out=values;
    if(drop)*drop=selected_photo_drop;
}
int sap_menu_install(const FH2ModApi *platform,FH2Mod *m,unsigned char *image,
                     const wchar_t *profiles,const wchar_t *config){
    if(!platform||!m||!image||!profiles||!config)return 0;
    /* Verify native 1.0.0.64 resource getter; do not blindly detour other builds. */
    static const unsigned char original_head[]={0x48,0x83,0xEC,0x18,0x48,0x8B,0x41,0x38};
    if(!mapped(image+NATIVE_GET_RESOURCE,sizeof original_head,0)||
       !bytes_eq(image+NATIVE_GET_RESOURCE,original_head,sizeof original_head)){
        platform->log(m,"StanceAirride: Springs menu resource code differs; UI hook skipped");return 0;
    }
    for(int i=0;i<MAX_PATH;i++){
       profile_path[i]=profiles[i];if(!profiles[i])break;
       if(i==MAX_PATH-1)return 0;
    }
    for(int i=0;i<MAX_PATH;i++){
       config_path[i]=config[i];if(!config[i])break;
       if(i==MAX_PATH-1)return 0;
    }
    bridge_api=platform;bridge_mod=m;game=image;
    FH2Hook *h=platform->hook_function(m,"Springs XAML resource loader",
                             image+NATIVE_GET_RESOURCE,(void*)resource_hook,(void**)&real_resource);
    if(!h){report("StanceAirride: Springs menu hook conflict; native menus unaffected");return 0;}
    if(!platform->enable_hooks(m,h)){
        platform->disable_hooks(m,h);
        report("StanceAirride: Springs menu hook activation conflicted; original menu retained");
        return 0;
    }
    report("StanceAirride: Springs UI hook enabled (4 stance sliders plus photo depth)");
    return 1;
}
