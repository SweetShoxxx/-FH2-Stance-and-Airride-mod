/* Standalone FH2 Mod Platform optical stance and photo-airride port.
   License GPL-3.0-or-later (derived geometry and lifecycle from the Extra Options port).
   Works with game 1.0.0.64, Azimuth 0.9.10; signatures guarded, hooks are
   ALWAYS platform-managed; no Azimuth/Extra Options file changes. */
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include "stance_atomic_intrinsics.h"
#include <stdint.h>
#include <stddef.h>
#include <wchar.h>
#include "fh2mod_api3_subset.h"
#include "stance_lifecycle.h"
#include "stance_camber_math.h"
#include "stance_track_math.h"
#include "stance_photo_math.h"
#include "stance_profile_values.h"
#include "airride_logic.h"
#include "stance_airride_context.h"
#include "stance_menu_platform.h"
#include "stance_spring_bounds_platform.h"

#define RVA_CAR_VT 0x02C5CB80u
#define RVA_CAR_UPDATE_SLOT 0x02C5CC00u
#define RVA_NATIVE_CAR_UPDATE 0x002A9400u
#define RVA_CREATOR1 0x02EC1490u
#define RVA_CREATOR2 0x02EC2BB0u
#define RVA_UPDATE1 0x02EC1878u
#define RVA_UPDATE2 0x02EC2F98u
#define RVA_NATIVE_CREATOR 0x0138E3E0u
#define RVA_NATIVE_UPDATE 0x013B7810u
#define RVA_SCENE_VT 0x02EA8DC8u
#define RVA_TIRE_VT 0x02EA9110u
#define RVA_WHEEL_VT 0x02EA9238u
#define RVA_TIRE_SITE 0x013AF06Cu
#define RVA_WHEEL_SITE 0x013AF086u
#define RVA_BODY_SITE 0x0137C6B2u
#define RVA_PLAYER_MANAGER 0x034ABA60u
#define RVA_GET_LOCAL_PLAYER 0x0021E0C0u
#define RVA_GET_PLAYER_CAR 0x002DA060u
#define MAX_SCENES 64
#define WHEEL_COUNT 4

static const FH2ModApi *api;
static FH2Mod *mod;
static unsigned char *img;
static wchar_t profiles_file[MAX_PATH], config_file[MAX_PATH];
static volatile LONG active_scene_index=-1, scene_lock;
static void * volatile chosen_scene;
static unsigned char *chosen_scene_owner;
static volatile LONG scene_generation;
static StanceLifecycle lifecycle;
static StanceProfileValues current_profile;
static unsigned active_model;
static AirrideLogic airride;
static volatile LONG center_bits[4][3],center_valid[4];
static int camber_sign=1;
static int last_f8;
static int photo_enabled=1, auto_scene_enabled=1, enable_only_on_lexus=0;
static int selected_streak, selected_candidate=-1, selected_valid;
static uint64_t last_scan_ms,last_report_ms;
static volatile LONG render_tire_count,render_wheel_count,body_count,rebind_count;
static volatile LONG identity_lock;
static volatile LONGLONG last_native_player_ms, last_fallback_poll_ms;
static volatile LONG menu_refresh_count, fallback_refresh_count;

typedef void (*CarUpdate)(void *,float,float,unsigned);
typedef void *(*SceneCreator)(void *,void *);
typedef uintptr_t (*SceneUpdate)(void *);
typedef void (*PartSet)(void *,unsigned,const float *,void *,void *);
typedef void *(*BodySet)(void *,const float *);
static CarUpdate original_car_update;
static SceneCreator original_creator;
static SceneUpdate original_update;
static PartSet original_tire,original_wheel;
static BodySet original_body;

typedef struct Scene {
    volatile LONG state; /* 0 free, 1 owned for writer, 2 live */
    void *owner,*owner_vt,*scene;
    volatile LONG updates;
} Scene;
static Scene scenes[MAX_SCENES];

/* Avoid the host application's CRT entirely. These helpers deliberately do
   not call or export any C runtime symbol (sprintf, swprintf, memcpy, etc.).
   Volatile byte copies also avoid compiler-generated memcpy calls. */
static void copy_bytes(void *dest,const void *src,size_t n){
    volatile unsigned char *d=(volatile unsigned char*)dest;
    const volatile unsigned char *s=(const volatile unsigned char*)src;
    for(size_t i=0;i<n;i++)d[i]=s[i];
}
static int equal_bytes(const void *a,const void *b,size_t n){
    const volatile unsigned char *p=(const volatile unsigned char*)a;
    const volatile unsigned char *q=(const volatile unsigned char*)b;
    for(size_t i=0;i<n;i++)if(p[i]!=q[i])return 0;
    return 1;
}
static size_t append_dec(char *out,size_t cap,size_t pos,unsigned value){
    char digits[16];unsigned count=0;
    do { digits[count++]=(char)('0'+value%10u);value/=10u; }while(value&&count<sizeof digits);
    while(count){if(pos+1>=cap)return 0;out[pos++]=digits[--count];}
    out[pos]=0;return pos;
}
static void say(const char *s){if(api&&mod)api->log(mod,s);}
static void metric(const char *name, int value){
    char buf[192];size_t pos=0;
    if(!name)return;
    while(name[pos]&&pos+2<sizeof buf){buf[pos]=name[pos];pos++;}
    if(name[pos]||pos+2>=sizeof buf)return;
    buf[pos++]='=';
    if(value<0){if(pos+2>=sizeof buf)return;buf[pos++]='-';}
    unsigned magnitude=value<0?((unsigned)(-(value+1))+1u):(unsigned)value;
    if(!append_dec(buf,sizeof buf,pos,magnitude))return;
    say(buf);
}
static int profile_section(wchar_t *out,size_t cap,uint32_t model){
    static const wchar_t prefix[]=L"model_";
    size_t pos=0;
    if(!out||cap<sizeof prefix/sizeof prefix[0]+1u)return 0;
    for(size_t i=0;i<sizeof prefix/sizeof prefix[0]-1u;i++)out[pos++]=prefix[i];
    wchar_t rev[16];unsigned n=0;
    do {rev[n++]=(wchar_t)(L'0'+model%10u);model/=10u;}while(model&&n<16u);
    if(pos+n>=cap)return 0;
    while(n)out[pos++]=rev[--n];
    out[pos]=0;return 1;
}
static int build_profile_path(wchar_t *out,size_t cap,const wchar_t *dir,
                              const wchar_t *suffix){
    size_t pos=0;
    if(!out||!dir||!suffix||cap<2)return 0;
    while(*dir){if(pos+1>=cap)return 0;out[pos++]=*dir++;}
    while(*suffix){if(pos+1>=cap)return 0;out[pos++]=*suffix++;}
    out[pos]=0;return 1;
}
static int readable(const void *ptr,size_t n,int write){
    MEMORY_BASIC_INFORMATION info;
    if(!ptr || !n || n>0x100000u || !VirtualQuery(ptr,&info,sizeof info))return 0;
    if(info.State!=MEM_COMMIT || (info.Protect&(PAGE_GUARD|PAGE_NOACCESS)))return 0;
    uintptr_t a=(uintptr_t)ptr, e=(uintptr_t)info.BaseAddress+info.RegionSize;
    if(a>UINTPTR_MAX-n || a+n>e)return 0;
    DWORD p=info.Protect&0xff;
    if(write) return p==PAGE_READWRITE||p==PAGE_EXECUTE_READWRITE||p==PAGE_WRITECOPY||p==PAGE_EXECUTE_WRITECOPY;
    return p==PAGE_READONLY||p==PAGE_READWRITE||p==PAGE_WRITECOPY||
           p==PAGE_EXECUTE_READ||p==PAGE_EXECUTE_READWRITE||p==PAGE_EXECUTE_WRITECOPY;
}
static int memread(const void *p,void *out,size_t n){
    if(!out||!readable(p,n,0))return 0;
    copy_bytes(out,p,n);return 1;
}
static void *pointer(const void *p){void *v=NULL;return memread(p,&v,sizeof v)?v:NULL;}
static int is_vt(void *p,uintptr_t rva){return p&&pointer(p)==img+rva;}
static int finite3(const float *p){
    return p && p[0]>-50000.f&&p[0]<50000.f&&
           p[1]>-50000.f&&p[1]<50000.f&&p[2]>-50000.f&&p[2]<50000.f;
}
static uint64_t stamp(void){return GetTickCount64();}
static int foreground(void){
    HWND w=GetForegroundWindow(); DWORD pid=0;
    if(!w)return 0;GetWindowThreadProcessId(w,&pid);
    return pid==GetCurrentProcessId();
}
static int load_profile(uint32_t id,StanceProfileValues *out){
    if(!id||!out)return 0;
    const wchar_t *keys[]={L"front_camber_tenths",L"rear_camber_tenths",
        L"front_height_mm",L"rear_height_mm",L"front_track_mm",L"rear_track_mm"};
    wchar_t section[32],buf[32];int vals[6]={0};
    if(!profile_section(section,32,id))return 0;
    /* Missing section yields neutral stance, NEVER writes to user file. */
    for(int i=0;i<6;i++){
        DWORD len=GetPrivateProfileStringW(section,keys[i],L"0",buf,32,profiles_file);
        if(!len||len>=31||!stance_profile_parse_integer(buf,&vals[i]))return 0;
    }
    *out=(StanceProfileValues){vals[0],vals[1],vals[2],vals[3],vals[4],vals[5]};
    return stance_profile_values_valid(out);
}
static void refresh_profile(unsigned model){
    StanceProfileValues next={0};
    if(!load_profile(model,&next)){say("StanceAirride: invalid profile; neutral geometry");}
    current_profile=next;active_model=model;
    sap_menu_select(model,&next,photo_enabled);
}
static void invalidate_scene(const char *why,int forget_airride){
    sa_xchgptr((PVOID volatile *)&chosen_scene,NULL);
    chosen_scene_owner=NULL;
    sa_xchg32(&active_scene_index,-1);
    for(int i=0;i<4;i++)sa_xchg32(&center_valid[i],0);
    selected_candidate=-1;selected_streak=0;selected_valid=0;
    /* Scene recreation during a pause, showroom or photo-mode transition
       MUST NOT raise the currently lowered car. A genuinely different car
       and the explicit F8 reset are the only hard reset callers. */
    if(forget_airride)stance_airride_reset_for_new_car(&airride);
    else stance_airride_hold_during_menu(&airride,stamp());
    sa_inc32(&scene_generation);
    sa_inc32(&rebind_count);
    say(why);
}
static void reset_scene(const char *why){invalidate_scene(why,1);}
static void rebind_scene(const char *why){invalidate_scene(why,0);}
static int scene_live(Scene *s){
    if(!s||sa_cmpxchg32(&s->state,2,2)!=2)return 0;
    if(!s->owner||!s->scene||pointer(s->owner)!=s->owner_vt||
       pointer((unsigned char*)s->owner+0x1278)!=s->scene||
       !is_vt(s->scene,RVA_SCENE_VT))return 0;
    return 1;
}
static int selected_scene_live(void *scene){
    LONG i=sa_cmpxchg32(&active_scene_index,-1,-1);
    return i>=0&&i<MAX_SCENES && scene==sa_cmpxchgptr(
        (PVOID volatile*)&chosen_scene,NULL,NULL) && scene_live(&scenes[i]);
}
static void capture_scene(void *owner){
    if(!owner || sa_cmpxchg32(&scene_lock,1,0)!=0)return;
    void *scene=pointer((unsigned char*)owner+0x1278);
    if(!is_vt(scene,RVA_SCENE_VT))goto done;
    for(int i=0;i<MAX_SCENES;i++){
        Scene *s=&scenes[i];
        if(sa_cmpxchg32(&s->state,0,0)==2&&s->scene==scene)goto done;
    }
    for(int i=0;i<MAX_SCENES;i++){
        Scene *s=&scenes[i];
        LONG state=sa_cmpxchg32(&s->state,0,0);
        if(state==0 || (state==2&&!scene_live(s))){
            sa_xchg32(&s->state,1);
            s->owner=owner;s->owner_vt=pointer(owner);s->scene=scene;
            sa_xchg32(&s->updates,0);
            sa_xchg32(&s->state,2);
            break;
        }
    }
done:sa_xchg32(&scene_lock,0);
}
static void *scene_creator(void *owner,void *ctx){
    void *r=original_creator(owner,ctx);
    capture_scene(owner);
    return r;
}
static void fallback_player_poll(void);
static uintptr_t scene_update(void *owner){
    for(int i=0;i<MAX_SCENES;i++)if(scenes[i].owner==owner&&scene_live(&scenes[i])){
        sa_inc32(&scenes[i].updates);break;
    }
    uintptr_t rc=original_update(owner);
    /* This path continues firing when the new car no longer reaches the
       older native CarUpdate route (showroom, upgrades, racing, fast travel). */
    fallback_player_poll();
    return rc;
}
static void *local_car(void){
    void *manager=pointer(img+RVA_PLAYER_MANAGER);
    if(!manager)return NULL;
    typedef void *(*PlayerGetter)(void *,int);
    typedef void *(*CarGetter)(void *,void **);
    void *player=((PlayerGetter)(img+RVA_GET_LOCAL_PLAYER))(manager,0);
    if(!player)return NULL;
    void *car=NULL;
    ((CarGetter)(img+RVA_GET_PLAYER_CAR))(player,&car);
    if(!is_vt(car,RVA_CAR_VT)){
        if(car){void **vt=pointer(car);if(vt&&readable(vt+3,8,0)){
            void (*release)(void*)=(void(*)(void*))vt[3];if(release)release(car);
        }}
        return NULL;
    }
    return car;
}
static void release_car(void *car){
    if(!car)return;void **vt=(void**)pointer(car);
    if(vt&&readable(vt+3,8,0)){
        void (*release)(void*)=(void(*)(void*))vt[3];if(release)release(car);
    }
}
static int player_position(void *car,float pos[4]){
    unsigned char *target=(unsigned char*)car+0x20;
    void *body=pointer(target+0x4be8);
    void *vt=pointer(body);
    if(!is_vt(target,0x02C5CE28u)||!vt||
       pointer(img+0x02C5CE28u)!=img+0xF62290u||
       !readable((unsigned char*)vt+0x270,8,0))return 0;
    void *getter=pointer((unsigned char*)vt+0x270);
    if((uintptr_t)getter<(uintptr_t)img+0x1000||
       (uintptr_t)getter>=(uintptr_t)img+0x1DCC000)return 0;
    typedef void *(*PositionFn)(void *,float *);
    ((PositionFn)(img+0xF62290u))(target,pos);
    return finite3(pos);
}
static int stationary(void *car){
    unsigned char *target=(unsigned char*)car+0x20;
    if(!is_vt(target,0x02C5CE28u))return 0;
    typedef void *(*VelocityFn)(void *,float *);
    __declspec(align(16)) float v[4]={0};
    ((VelocityFn)(img+0xF646B0u))(target,v);
    return finite3(v)&&v[0]*v[0]+v[1]*v[1]+v[2]*v[2]<=0.01f;
}
static void release_shared(void *object,void *counter){
    (void)object;
    if(counter&&readable((unsigned char*)counter+12,4,1)){
        if(sa_dec32((volatile LONG*)((unsigned char*)counter+8))==0){
            void **vt=(void**)pointer(counter);
            if(vt&&readable(vt,16,0)){
                void(*d0)(void*)=(void(*)(void*))vt[0];if(d0)d0(counter);
                if(sa_dec32((volatile LONG*)((unsigned char*)counter+12))==0){
                    void(*d1)(void*)=(void(*)(void*))vt[1];if(d1)d1(counter);
                }
            }
        }
    }
}
static int freeroam(void){
    void *manager=pointer(img+RVA_PLAYER_MANAGER);
    void *simulation=pointer((unsigned char*)manager+0x48);
    unsigned char paused=1;
    if(!manager||!simulation||!memread((unsigned char*)simulation+0x28,&paused,1)||paused)return 0;
    void *hud=pointer(img+0x034C0F40u);
    void *services=pointer((unsigned char*)hud+8);
    if(!hud||!services)return 0;
    struct {void *object,*counter;} ctx={0};
    typedef void *(*SharedGet)(void *,void *);
    ((SharedGet)(img+0x002129A0u))(hud,&ctx);
    int mode=-1;
    if(ctx.object)memread((unsigned char*)ctx.object+0x60,&mode,4);
    if(ctx.counter)release_shared(ctx.object,ctx.counter);
    return mode==2;
}
static int button_l3(void){
    void *manager=pointer(img+0x0365D7C8u);
    if(!is_vt(manager,0x02E7A2E8u))return 0;
    void *controller=pointer((unsigned char*)manager+0xab28);
    if(!controller)return 0;
    unsigned char connected=0;unsigned short buttons=0;
    if(!memread((unsigned char*)controller+4,&connected,1)||connected!=1||
       !memread((unsigned char*)controller+0xc0,&buttons,2))return 0;
    return (buttons&0x40u)!=0;
}
static void maybe_lock_scene(void *car){
    uint64_t now=stamp();
    if(now-last_scan_ms<250)return;
    last_scan_ms=now;
    if(!auto_scene_enabled || (enable_only_on_lexus&&active_model!=1535u))return;
    float pos[4]={0};
    if(!player_position(car,pos))return;
    float best=1e30f,runner=1e30f;int idx=-1;
    for(int i=0;i<MAX_SCENES;i++){
        Scene *s=&scenes[i];
        if(!scene_live(s)||sa_cmpxchg32(&s->updates,0,0)<3)continue;
        void *tire=pointer((unsigned char*)s->scene+0xC20);
        void *wheel=pointer((unsigned char*)s->scene+0xC28);
        void *root=pointer((unsigned char*)s->scene+0x160);
        if(!is_vt(tire,RVA_TIRE_VT)||!is_vt(wheel,RVA_WHEEL_VT)||!root)continue;
        float m[16]={0};
        if(!memread((unsigned char*)root+0x10,m,sizeof m)||!finite3(m+12))continue;
        float sq=0;for(int j=0;j<3;j++){float d=pos[j]-m[12+j];sq+=d*d;}
        if(sq<best){runner=best;best=sq;idx=i;}
        else if(sq<runner)runner=sq;
    }
    /* Player scene is uniquely near the player; other nearby cars invalidate. */
    if(idx<0||best>9.f||runner<49.f){selected_streak=0;selected_candidate=-1;return;}
    if(idx==selected_candidate)selected_streak++;
    else {selected_candidate=idx;selected_streak=1;}
    if(selected_streak>=6 && (!selected_scene_live(scenes[idx].scene) ||
         sa_cmpxchg32(&active_scene_index,-1,-1)!=idx)){
        rebind_scene("StanceAirride: new unique local scene acquired (airride retained)");
        chosen_scene_owner=scenes[idx].owner;
        sa_xchgptr((PVOID volatile*)&chosen_scene,scenes[idx].scene);
        sa_xchg32(&active_scene_index,idx);
        selected_streak=6;selected_candidate=idx;selected_valid=1;
    }
}
static void photo_controls(void *car,uint64_t now){
    int ctx=foreground() && freeroam() && selected_valid &&
        selected_scene_live(sa_cmpxchgptr((PVOID volatile*)&chosen_scene,NULL,NULL));
    /* Layout-aware '-' for German/US keyboards; keypad Minus always works. */
    short mapped=VkKeyScanW(L'-');
    int minus_vk=mapped==-1 ? VK_OEM_MINUS : (mapped&0xff);
    int modifiers=mapped==-1 ? 0 : ((mapped>>8)&0xff);
    int minus=(modifiers==0 && (GetAsyncKeyState(minus_vk)&0x8000)!=0) ||
              (GetAsyncKeyState(VK_SUBTRACT)&0x8000)!=0;
    int l3=button_l3();
    /* Use exactly v5.81 optical airride state machine. */
    if(ctx){
        (void)airride_logic_step(&airride,minus,l3,1,stationary(car),now);
    }else{
        /* Pause/photo UI is not an intent to raise the car. The old code
           passed allowed=0 and actively retracted while opening any menu. */
        stance_airride_hold_during_menu(&airride,now);
    }
    int f8=(GetAsyncKeyState(VK_F8)&0x8000)!=0;
    if(f8&&!last_f8)reset_scene("StanceAirride: manual reset (F8)");
    last_f8=f8;
}
/* Reconcile the actual local-player car independently of the native car
   update callback. This is also called before reading/writing a menu slider.
   Never treat a preview vehicle or arbitrary scene as player-owned. */
static int observe_verified_player(void *car, int with_scene, int with_controls){
    if(!car || sa_cmpxchg32(&identity_lock,1,0)!=0)return 0;
    unsigned model=0;
    if(!is_vt(car,RVA_CAR_VT)||
       !memread((unsigned char*)car+0x118,&model,4)||!model||model>=1000000u){
        sa_xchg32(&identity_lock,0);
        return 0;
    }
    void *body=NULL;
    if(is_vt((unsigned char*)car+0x20,0x02C5CE28u))
        body=pointer((unsigned char*)car+0x20+0x4be8);
    uint64_t now=stamp();
    unsigned changed=stance_lifecycle_advance(&lifecycle,(uintptr_t)car,
                                (uintptr_t)body,model,freeroam(),now);
    if(changed&(STANCE_LIFE_CAR|STANCE_LIFE_MODEL)){
        reset_scene("StanceAirride: different local car; reset airride and rebind");
        refresh_profile(model);
    }else if(changed&STANCE_LIFE_BODY){
        rebind_scene("StanceAirride: physics body recreated; rebind but preserve photo airride");
        refresh_profile(model);
    }else if((changed&STANCE_LIFE_FIRST) || active_model!=model){
        refresh_profile(model);
    }
    /* GAP and CONTEXT alone never clear the player scene or airride:
       opening the Springs menu, pausing or entering photo mode is not a
       vehicle selection change. Invalid scenes are checked below. */
    if(changed&(STANCE_LIFE_FIRST|STANCE_LIFE_CAR|STANCE_LIFE_MODEL)){
        metric("StanceAirride: selected_player_model",(int)model);
        metric("StanceAirride: identity_change_mask",(int)changed);
    }
    /* A menu command for a brand-new model must never use the last car's
       cached binding even when the native update callback was not fired. */
    sap_bounds_observe_player(car,body,model);
    sap_menu_get(&current_profile,&airride.drop_cm);
    if(with_scene){
        if(!selected_scene_live(sa_cmpxchgptr(
                 (PVOID volatile*)&chosen_scene,NULL,NULL)))selected_valid=0;
        maybe_lock_scene(car);
    }
    if(with_controls&&photo_enabled)photo_controls(car,now);
    if(now-last_report_ms>=10000){
        last_report_ms=now;
        metric("StanceAirride scene_bound",selected_valid);
        metric("StanceAirride active_model",(int)active_model);
        metric("StanceAirride photo_mm",airride.current_mm);
        metric("StanceAirride render_tire",sa_cmpxchg32(&render_tire_count,0,0));
        metric("StanceAirride render_wheel",sa_cmpxchg32(&render_wheel_count,0,0));
        metric("StanceAirride native_body",sa_cmpxchg32(&body_count,0,0));
        metric("StanceAirride: fallback_polls",sa_cmpxchg32(&fallback_refresh_count,0,0));
        metric("StanceAirride: menu_synced",sa_cmpxchg32(&menu_refresh_count,0,0));
    }
    sa_xchg32(&identity_lock,0);
    return 1;
}
static int sync_player_for_menu(void){
    void *player=local_car();
    if(!player)return 0;
    int ok=observe_verified_player(player,0,0);
    release_car(player);
    if(ok)sa_inc32(&menu_refresh_count);
    return ok;
}
static void fallback_player_poll(void){
    uint64_t now=stamp();
    uint64_t last_native=(uint64_t)sa_cmpxchg64(&last_native_player_ms,0,0);
    /* Do not duplicate regular native player updates; only take over when
       that callback stopped (e.g. fresh vehicle after a purchase or race). */
    if(last_native && now>=last_native && now-last_native<400u)return;
    uint64_t last=(uint64_t)sa_cmpxchg64(&last_fallback_poll_ms,0,0);
    if(now>=last && now-last<250u)return;
    if(sa_cmpxchg64(&last_fallback_poll_ms,(LONGLONG)now,(LONGLONG)last)
           !=(LONGLONG)last)return;
    void *player=local_car();
    if(!player)return;
    if(observe_verified_player(player,1,1))
        sa_inc32(&fallback_refresh_count);
    release_car(player);
}
static void car_update(void *car,float dt,float frame_dt,unsigned frame){
    void *player=local_car();
    if(player==car){
        sa_xchg64(&last_native_player_ms,(LONGLONG)stamp());
        (void)observe_verified_player(car,1,1);
    }
    release_car(player);
    original_car_update(car,dt,frame_dt,frame);
}
static int wheel_centers(float center[4][3]){
    for(int i=0;i<4;i++){
        if(!sa_cmpxchg32(&center_valid[i],0,0))return 0;
        for(int j=0;j<3;j++){
            LONG bits=sa_cmpxchg32(&center_bits[i][j],0,0);
            copy_bytes(&center[i][j],&bits,4);
        }
    }
    return 1;
}
static void forward_part(int which,void *scene,unsigned wheel,const float *matrix,void *ctx,void *aux){
    PartSet original=which?original_wheel:original_tire;
    if(!original)return;
    if(wheel>=4||!selected_valid||!selected_scene_live(scene)||
       !readable(matrix,64,0)){original(scene,wheel,matrix,ctx,aux);return;}
    __declspec(align(16)) float tmp[16];copy_bytes(tmp,matrix,64);
    if(!stance_track_center_valid(tmp)){original(scene,wheel,matrix,ctx,aux);return;}
    for(int k=0;k<3;k++){
        LONG bits;copy_bytes(&bits,&tmp[12+k],4);
        sa_xchg32(&center_bits[wheel][k],bits);
    }
    sa_xchg32(&center_valid[wheel],1);
    float centers[4][3];
    if(!wheel_centers(centers)){original(scene,wheel,matrix,ctx,aux);return;}
    int front=wheel<2;
    int angle=front?current_profile.front_camber_tenths:current_profile.rear_camber_tenths;
    int track=front?current_profile.front_track_mm:current_profile.rear_track_mm;
    unsigned same_side=wheel==0?3:wheel==1?2:wheel==2?1:0;
    unsigned opposite=wheel==0?1:wheel==1?0:wheel==2?3:2;
    float front_pos[3],rear_pos[3];
    for(int j=0;j<3;j++){
        front_pos[j]=front?centers[wheel][j]:centers[same_side][j];
        rear_pos[j]=front?centers[same_side][j]:centers[wheel][j];
    }
    int mm=photo_enabled?airride.current_mm:0;
    if(mm>0 && mm<=50)
        (void)stance_camber_rotate_car_centidegrees(tmp,front_pos,rear_pos,wheel,angle*10-mm*5,camber_sign);
    else if(angle)
        (void)stance_camber_rotate_car(tmp,front_pos,rear_pos,wheel,angle,camber_sign);
    if(track)(void)stance_track_offset_apply(tmp,centers[opposite],track);
    if(mm>0&&mm<=50)(void)stance_photo_wheel_gap_shift(tmp,centers,mm);
    if(which)sa_inc32(&render_wheel_count);else sa_inc32(&render_tire_count);
    original(scene,wheel,tmp,ctx,aux);
}
static void tire_set(void *scene,unsigned wheel,const float *mat,void *ctx,void *aux){
    forward_part(0,scene,wheel,mat,ctx,aux);
}
static void wheel_set(void *scene,unsigned wheel,const float *mat,void *ctx,void *aux){
    forward_part(1,scene,wheel,mat,ctx,aux);
}
static void *body_set(void *target,const float *matrix){
    if(!original_body)return NULL;
    void *scene=sa_cmpxchgptr((PVOID volatile*)&chosen_scene,NULL,NULL);
    if(!target||!matrix||!selected_valid||!selected_scene_live(scene)||
       target!=pointer((unsigned char*)scene+0x160))return original_body(target,matrix);
    int mm=photo_enabled?airride.current_mm:0;
    if(mm<=0||mm>50)return original_body(target,matrix);
    float centers[4][3];
    if(!wheel_centers(centers))return original_body(target,matrix);
    /* Matrix at this call site is stack scratch; never change scene or game data.
       Restrict writing to aligned, mapped, writable memory near THIS stack. */
    char own_stack=0;
    uintptr_t a=(uintptr_t)matrix,b=(uintptr_t)&own_stack;
    uintptr_t distance=a>b?a-b:b-a;
    if(distance>0x80000u||(a&15u)||!readable(matrix,64,1))
        return original_body(target,matrix);
    __declspec(align(16)) float temp[16],check[16];
    if(!memread(matrix,temp,64))return original_body(target,matrix);
    copy_bytes(check,temp,64);
    if(!stance_photo_wheel_gap_shift(check,(const float (*)[3])centers,mm))
        return original_body(target,matrix);
    for(int k=0;k<3;k++)temp[12+k]-=check[12+k]-temp[12+k];
    copy_bytes((void*)matrix,temp,64);
    sa_inc32(&body_count);
    return original_body(target,matrix);
}
static int code_matches(uintptr_t rva,const unsigned char *expected,size_t n){
    return readable(img+rva,n,0)&&equal_bytes(img+rva,expected,n);
}
static int safe_add_hook(FH2Hook **hooks,int *n,FH2Hook *h,const char *name){
    if(!h){say(name);return 0;}
    hooks[(*n)++]=h;return 1;
}
static DWORD WINAPI install_worker(LPVOID unused){
    (void)unused;
    if(!api->wait_for_code){say("StanceAirride: wait_for_code missing");return 0;}
    img=(unsigned char*)api->wait_for_code(0xFFFFFFFFu);
    if(!img){say("StanceAirride: game code not ready; no hooks");return 0;}
    /* Ensure no hooks are installed if game signatures differ. Platform will
       separately reject any overlap with Extra Options or another mod. */
    static const unsigned char tcall[]={0xE8,0x8F,0x97,0xE0,0xFF};
    static const unsigned char wcall[]={0xE8,0xB5,0xA6,0xE0,0xFF};
    static const unsigned char bcall[]={0xE8,0x29,0x7F,0x38,0x00};
    static const unsigned char car_head[]={0x48,0x8B,0xC4,0x48,0x89,0x58,0x18,0x57};
    static const unsigned char scene_head[]={0x48,0x89,0x54,0x24,0x10,0x55,0x53,0x56};
    static const unsigned char update_head[]={0x4C,0x8B,0xDC,0x41,0x56,0x48,0x83,0xEC};
    if(!code_matches(RVA_NATIVE_CAR_UPDATE,car_head,sizeof car_head)||
       !code_matches(RVA_NATIVE_CREATOR,scene_head,sizeof scene_head)||
       !code_matches(RVA_NATIVE_UPDATE,update_head,sizeof update_head)||
       !code_matches(RVA_TIRE_SITE,tcall,5)||
       !code_matches(RVA_WHEEL_SITE,wcall,5)||
       !code_matches(RVA_BODY_SITE,bcall,5)){
        say("StanceAirride: signature mismatch; all hooks disabled");return 0;
    }
    FH2Hook *hooks[6];int n=0;
    /* Hook the native functions, not the car/scene vtable slots. This
       deliberately avoids Extra Options' existing vtable-pointer hooks:
       those wrappers already forward to the native function we intercept. */
    if(!safe_add_hook(hooks,&n,api->hook_function(mod,"native car update",
                img+RVA_NATIVE_CAR_UPDATE,(void*)car_update,(void**)&original_car_update),
                "StanceAirride: native car update hook conflict"))goto fail;
    if(!safe_add_hook(hooks,&n,api->hook_function(mod,"native scene creator",
                img+RVA_NATIVE_CREATOR,(void*)scene_creator,(void**)&original_creator),
                "StanceAirride: native scene creator hook conflict"))goto fail;
    if(!safe_add_hook(hooks,&n,api->hook_function(mod,"native scene update",
                img+RVA_NATIVE_UPDATE,(void*)scene_update,(void**)&original_update),
                "StanceAirride: native scene update hook conflict"))goto fail;
    if(!safe_add_hook(hooks,&n,api->hook_call(mod,"tire transform",img+RVA_TIRE_SITE,
                (void*)tire_set,(void**)&original_tire),"StanceAirride: tire call collision"))goto fail;
    if(!safe_add_hook(hooks,&n,api->hook_call(mod,"wheel transform",img+RVA_WHEEL_SITE,
                (void*)wheel_set,(void**)&original_wheel),"StanceAirride: wheel call collision"))goto fail;
    if(!safe_add_hook(hooks,&n,api->hook_call(mod,"body transform",img+RVA_BODY_SITE,
                (void*)body_set,(void**)&original_body),"StanceAirride: body call collision"))goto fail;
    /* Each created core hook is disabled. Enabling as a GROUP reduces thread pauses. */
    if(!api->enable_hooks(mod,NULL)){
        say("StanceAirride: hook conflict, disabled");api->disable_hooks(mod,NULL);return 0;
    }
    say("StanceAirride: six platform-managed optical hooks active");
    if(GetPrivateProfileIntW(L"General",L"spring_bounds_extension",1,config_file)!=0)
        (void)sap_bounds_install(api,mod,img);
    /* UI is OPTIONAL and enabled only after the six core hooks, so a menu
       collision does not disable Stance/Airride geometry and input. */
    sap_menu_set_player_sync(sync_player_for_menu);
    if(GetPrivateProfileIntW(L"General",L"springs_menu",1,config_file)!=0)
        (void)sap_menu_install(api,mod,img,profiles_file,config_file);
    return 0;
fail:
    api->disable_hooks(mod,NULL);
    say("StanceAirride: one or more required hooks unavailable; no optical changes");
    return 0;
}
FH2MOD_EXPORT int fh2mod_init(const FH2ModApi *platform){
    if(!platform || platform->api_version<3 ||
       platform->size<sizeof(FH2ModApi))return 1;
    api=platform;
    FH2ModInfo info={0};
    info.size=sizeof(info);info.name="StanceAirride";info.version="0.1.8-v565-legacy-springs-beta";
    info.github_repo=NULL;info.platform_version="2.7.2";info.check_updates=0;
    info.description="Optical stance & photo-airride. Individual profiles; no Azimuth file replacement.";
    mod=api->register_mod(&info);
    if(!mod)return 1;
    if(!api->azimuth_dir)return 1;
    if(!build_profile_path(profiles_file,MAX_PATH,api->azimuth_dir,
                          L"\\StanceAirride\\Profiles.ini") ||
       !build_profile_path(config_file,MAX_PATH,api->azimuth_dir,
                          L"\\StanceAirride\\StanceAirride.ini")){
       say("StanceAirride: invalid data path");return 1;
    }
    if(!GetPrivateProfileIntW(L"General",L"enabled",1,config_file)){
        say("StanceAirride: disabled in own config");return 0;
    }
    photo_enabled=GetPrivateProfileIntW(L"General",L"photo_airride",1,config_file)!=0;
    auto_scene_enabled=GetPrivateProfileIntW(L"General",L"auto_scene",1,config_file)!=0;
    enable_only_on_lexus=GetPrivateProfileIntW(L"General",L"lexus_only",0,config_file)!=0;
    airride.drop_cm=GetPrivateProfileIntW(L"Airride",L"drop_cm",3,config_file);
    if(airride.drop_cm<2||airride.drop_cm>5)airride.drop_cm=3;
    say("StanceAirride registered: separate FH2 Mod Platform module, no winmm/azimuth-tls replacement");
    HANDLE thread=CreateThread(NULL,0,install_worker,NULL,0,NULL);
    if(!thread){say("StanceAirride: cannot spawn hook installer");return 1;}
    CloseHandle(thread);
    return 0;
}
