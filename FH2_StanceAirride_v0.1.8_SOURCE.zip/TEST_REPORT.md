# Testreport: v0.1.8 Legacy v5.65 Springs Port

## Auswertungsgrundlage

- Ursprüngliche v5.65-`winmm.dll`: enthält in der kompilierten Binärdatei die Strategien `STANCE_GLOBAL_V562` (alle geeigneten Loader-Zeilen), `STANCE_STARTUP_V560` (früh geladene Zeilen) und `STANCE_GENERIC_V556` (Tuning-Seite-gesteuert). Die Global-Strategie war in v5.65 **nur nach ausdrücklichem Opt-in aktiv**.
- `platform(3).log`: v0.1.7 erkannte je 2 passende Federdatensätze pro Achse **vor** dem Laden der Tuning-Seite. v0.1.7 änderte dagegen erst den späteren Datensatz.

## Umgesetzte Änderungen

- `src/stance_spring_bounds_platform.c` nutzt wieder den globalen nativen Loader-Pfad aus der alten v5.65 (alle geeigneten Rows einschließlich früher Ladeaufrufe). Der Name der ursprünglichen Mod-Plattform-Hooks und die Signaturen wurden nicht geändert.
- Gültigkeitsprüfung und mathematische Min/Max-Erweiterung in `vendor/stance_spring_bounds_v565.h` akzeptieren auch Standardhöhe exakt an einer Reglergrenze. Nur Min/Max werden verändert; Default/Kompression/Streckung bleiben unverändert.
- Airride-, Fotomodus-, UI-/Stance-, Profil- und Fahrzeugwechselcode unverändert.
- Wichtig: globaler Modus kann AI-/Traffic-Fahrzeugdaten betreffen; alter v5.65-Text: `PLAYER_OWNERSHIP_NOT_PROVEN`.

## Lokal getestet / PASS

- Windows AMD64 DLL als PE32+ erstellt (Clang/LLVM lld-link, freestanding, kein CRT/DllMain).
- PE-Validator: nur `KERNEL32.dll` und `USER32.dll`; `fh2mod_init` exportiert, keine `Interlocked*`-DLL-Importe.
- Nativer Federloader-Mock: frühe Rows, weitere Rows, zweimal Grenzfall Default==Min/Max, physikalische Kappung, fehlerhafte Daten ausgeschlossen.
- Mathematiktest v5.65-inspirierte -3/+5cm-Grenzen.
- Bestandstests: v5.56-Mathematik, Airride-Hold im Menü, Profile, Foto-Geometrie, Stance-XAML-Slider, Model-Rebinding.
- Installations-ZIP enthält ausschließlich Plugin-DLL, Beispiel-INI, Dokumentation und Lizenzen. Keine fremden DLLs.

## NICHT getestet

- Echter Start auf Windows in Azimuth / FH2-Mod-Platform 2.7.2 und tatsächliche Federhöhen-Reglerwirkung.
- Kollisionen mit weiteren Mods oder Einfluss auf KI/Verkehr. Ausschließlich offline testen, vorher Backup.

## Hinweis zum Port

Die v5.65 liegt nur kompiliert vor; dies ist eine Neuimplementierung der erkennbaren globalen Loader-Strategie und der v5.60-Randfallbehandlung, keine beweisbare byteidentische Übernahme. Die originale v5.65 enthielt mehrere testweise per Marker aktivierbare Modi.
