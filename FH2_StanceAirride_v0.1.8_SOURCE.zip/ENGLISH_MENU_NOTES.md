See MENU_CHANGES.md for the current text cleanup and verification-dependent Car ID visibility. The source and binary here are compiled with this small UI-only change.
