/* MIT-licensed FH2 Mod Platform ABI (API v3 prefix) from
   https://github.com/Trinculo54/fh2-mod-platform/include/fh2mod.h
   Keep the exact order/types of all slots through wait_for_code.
   Consult upstream for new functions; this subset does not define later APIs. */
#ifndef FH2MOD_API3_SUBSET_H
#define FH2MOD_API3_SUBSET_H
#include <stdint.h>
#include <stddef.h>
#include <wchar.h>
#define FH2MOD_EXPORT __declspec(dllexport)
typedef struct FH2Mod FH2Mod;
typedef struct FH2Hook FH2Hook;
typedef struct FH2ModInfo {
    uint32_t size;
    const char *name, *version, *github_repo, *platform_version;
    int check_updates;
    const char *description;
} FH2ModInfo;
typedef struct FH2ModApi {
    uint32_t size, api_version;
    const char *platform_version;
    const wchar_t *azimuth_dir, *game_dir;
    FH2Mod *(*register_mod)(const FH2ModInfo *);
    void (*log)(FH2Mod *, const char *);
    void (*set_string)(FH2Mod *,const char *,uint16_t,const wchar_t *);
    void (*replace_string)(FH2Mod *,const char *,const wchar_t *,const wchar_t *);
    void (*clear_strings)(FH2Mod *,const char *);
    void (*apply_strings)(FH2Mod *);
    void (*set_notice)(FH2Mod *,const char *);
    void *(*game_base)(void);
    void *(*wait_for_game)(uint32_t);
    int (*set_file)(FH2Mod *,const char *,const void *,size_t);
    void (*clear_file)(FH2Mod *,const char *);
    void (*add_sql)(FH2Mod *,const char *);
    void (*clear_sql)(FH2Mod *);
    void (*apply_database)(FH2Mod *);
    void (*publish_interface)(FH2Mod *,const char *,uint32_t,const void *);
    const void *(*get_interface)(const char *,uint32_t);
    int (*wait_for_mods)(uint32_t);
    const char *(*mod_version)(const char *);
    FH2Hook *(*hook_function)(FH2Mod *,const char *,void *,void *,void **);
    FH2Hook *(*hook_call)(FH2Mod *,const char *,void *,void *,void **);
    FH2Hook *(*hook_pointer)(FH2Mod *,const char *,void **,void *,void **);
    int (*enable_hooks)(FH2Mod *,FH2Hook *);
    int (*disable_hooks)(FH2Mod *,FH2Hook *);
    void *(*wait_for_code)(uint32_t);
} FH2ModApi;
#endif
