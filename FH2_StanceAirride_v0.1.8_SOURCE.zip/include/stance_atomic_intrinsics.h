/* FH2 StanceAirride: freestanding x64 atomics (no Interlocked* DLL imports).
   Windows exposes Interlocked operations as compiler intrinsics in proper SDKs;
   they MUST NOT be declared as dynamically loaded kernel32.dll symbols.
   Sequential consistency matches the original Windows Interlocked semantics. */
#ifndef FH2_STANCE_ATOMIC_INTRINSICS_H
#define FH2_STANCE_ATOMIC_INTRINSICS_H
#include <windows.h>
static inline LONG sa_cmpxchg32(volatile LONG *p,LONG value,LONG expected){
    __atomic_compare_exchange_n(p,&expected,value,0,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);
    return expected;
}
static inline LONGLONG sa_cmpxchg64(volatile LONGLONG *p,LONGLONG value,LONGLONG expected){
    __atomic_compare_exchange_n(p,&expected,value,0,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);
    return expected;
}
static inline LONG sa_xchg32(volatile LONG *p,LONG value){
    return __atomic_exchange_n(p,value,__ATOMIC_SEQ_CST);
}
static inline LONGLONG sa_xchg64(volatile LONGLONG *p,LONGLONG value){
    return __atomic_exchange_n(p,value,__ATOMIC_SEQ_CST);
}
static inline LONG sa_inc32(volatile LONG *p){
    return __atomic_add_fetch(p,1,__ATOMIC_SEQ_CST);
}
static inline LONG sa_dec32(volatile LONG *p){
    return __atomic_sub_fetch(p,1,__ATOMIC_SEQ_CST);
}
static inline PVOID sa_cmpxchgptr(PVOID volatile *p,PVOID value,PVOID expected){
    __atomic_compare_exchange_n(p,&expected,value,0,__ATOMIC_SEQ_CST,__ATOMIC_SEQ_CST);
    return expected;
}
static inline PVOID sa_xchgptr(PVOID volatile *p,PVOID value){
    return __atomic_exchange_n(p,value,__ATOMIC_SEQ_CST);
}
#endif
