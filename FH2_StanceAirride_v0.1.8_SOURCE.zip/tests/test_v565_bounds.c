#include <assert.h>
#include <stdio.h>
#include "stance_spring_bounds_v565.h"
static void approx(float a,float b){assert(a>b-0.0001f&&a<b+0.0001f);}
int main(void){
    float a[]={.1825f,.1734f,.2198f,.1368f,.1665f},mn,mx;
    int ls,hs;
    assert(fh2_v565_calculate(a,&mn,&mx,&ls,&hs));
    approx(mn,.1434f);approx(mx,.2698f);assert(ls==FH2_V565_FULL&&hs==FH2_V565_FULL);
    float b[]={.2f,.2f,.2f,.15f,.1f};
    assert(fh2_v565_calculate(b,&mn,&mx,&ls,&hs));
    approx(mn,.17f);approx(mx,.25f);
    float c[]={.2f,.25f,.2f,.15f,.1f};
    assert(!fh2_v565_calculate(c,&mn,&mx,&ls,&hs));
    float d[]={.2f,.17f,.23f,.166f,.1f};
    assert(!fh2_v565_calculate(d,&mn,&mx,&ls,&hs));
    puts("PASS: v565 pure bounds (-3/+5cm), default-at-edge, reversed bounds, invalid compression");
    return 0;
}
