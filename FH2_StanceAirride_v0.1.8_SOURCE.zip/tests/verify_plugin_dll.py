#!/usr/bin/env python3
"""Check exact PE import/export table without third-party Python packages.
Windows x64; self-contained FH2Mod plugin, no C runtime load dependency.
"""
import struct
import sys
from pathlib import Path

blob = Path(sys.argv[1]).read_bytes()
def u16(at): return struct.unpack_from("<H", blob, at)[0]
def u32(at): return struct.unpack_from("<I", blob, at)[0]
def u64(at): return struct.unpack_from("<Q", blob, at)[0]
def cstr(at):
    end=blob.index(0,at)
    return blob[at:end].decode("ascii")
assert blob[:2]==b"MZ"
pe=u32(0x3c)
assert blob[pe:pe+4]==b"PE\0\0"
assert u16(pe+4)==0x8664, "expected AMD64"
nsects=u16(pe+6); opts=u16(pe+20)
optional=pe+24
assert u16(optional)==0x20b, "expected PE32+"
assert u16(pe+22) & 0x2000, "expected DLL"
assert u32(optional+16)==0, "DLL needs no C-runtime entrypoint"
secstart=optional+opts
sects=[]
for i in range(nsects):
    h=secstart+i*40
    virtual_size=u32(h+8)
    rva=u32(h+12)
    raw_size=u32(h+16)
    file_offset=u32(h+20)
    sects.append((rva,max(virtual_size,raw_size),raw_size,file_offset))
def translate(rva):
    for base,size,raw_size,off in sects:
        if base<=rva<base+size and rva-base<raw_size:
            return off+rva-base
    raise AssertionError(f"Unmapped PE RVA {rva:x}")
# IMAGE_DATA_DIRECTORY starts 112 bytes after the optional PE32+ header.
datadir=optional+112
export_rva=u32(datadir)
import_rva=u32(datadir+8)
assert export_rva and import_rva
imp_at=translate(import_rva)
imports={}
for i in range(64):
    d=imp_at+20*i
    ilt,time,fwd,dll_rva,iat=struct.unpack_from("<IIIII",blob,d)
    if not (ilt or time or fwd or dll_rva or iat):break
    name=cstr(translate(dll_rva)).lower()
    assert name not in imports
    thunk=translate(ilt or iat)
    symbols=[]
    for j in range(128):
        addr=u64(thunk+j*8)
        if not addr:break
        assert addr>>63==0, "ordinal import unexpected"
        symbols.append(cstr(translate(addr)+2))
    imports[name]=symbols
else: raise AssertionError("too many import descriptors")
assert set(imports)=={"kernel32.dll","user32.dll"},imports
assert all("interlocked" not in sym.lower() for values in imports.values() for sym in values), imports
assert all("printf" not in sym and "memcpy" not in sym and "memcmp" not in sym
           for values in imports.values() for sym in values),imports
export_at=translate(export_rva)
num_names=u32(export_at+24)
name_rvas=translate(u32(export_at+32))
exports=[cstr(translate(u32(name_rvas+i*4))) for i in range(num_names)]
assert exports==["fh2mod_init"],exports
print("PASS: PE32+ AMD64 DLL, no CRT entrypoint, exports fh2mod_init")
print("PASS: imports ONLY KERNEL32.dll and USER32.dll (no Interlocked*/CRT imports)")
