#include <stdio.h>
#include <stdint.h>
#include <assert.h>
#include <wchar.h>
#include "stance_lifecycle.h"
#include "stance_track_math.h"
#include "stance_camber_math.h"
#include "stance_photo_math.h"
#include "stance_profile_values.h"
#include "airride_logic.h"
static void lifecycle_test(void){
    StanceLifecycle l={0};
    assert(stance_lifecycle_advance(&l,0x1000,0x2000,1535,1,1000)==STANCE_LIFE_FIRST);
    assert(stance_lifecycle_advance(&l,0x1000,0x2000,1535,1,1200)==0);
    assert(stance_lifecycle_advance(&l,0x1000,0x3000,1535,1,1300)==STANCE_LIFE_BODY);
    assert(stance_lifecycle_advance(&l,0x1000,0x3000,1535,0,1500)==STANCE_LIFE_CONTEXT);
    assert(stance_lifecycle_advance(&l,0x1000,0x3000,1535,0,5000)==STANCE_LIFE_GAP);
    assert(stance_lifecycle_advance(&l,0x5000,0x3000,1000,1,5100)==
           (STANCE_LIFE_CAR|STANCE_LIFE_MODEL|STANCE_LIFE_CONTEXT));
}
static void profile_test(void){
    StanceProfileValues p={-20,-20,-150,-150,45,48};
    assert(stance_profile_values_valid(&p));
    p.front_track_mm=101;assert(!stance_profile_values_valid(&p));
    p.front_track_mm=45;assert(stance_profile_values_valid(&p));
    wchar_t section[32];assert(stance_profile_section_name(1535,section,32));
    assert(wcscmp(section,L"model_1535")==0);
}
static void photo_test(void){
    float center[4][3]={{-0.8f,0.f,1.3f},{0.8f,0.f,1.3f},
                        {0.8f,0.f,-1.3f},{-0.8f,0.f,-1.3f}};
    float m[16]={1,0,0,0,0,1,0,0,0,0,1,0,-0.8f,0.f,1.3f,1};
    assert(stance_photo_wheel_gap_shift(m,center,30));
    assert(m[13]>0.029f && m[13]<0.031f);
    assert(!stance_photo_wheel_gap_shift(m,center,99));
    assert(stance_track_offset_apply(m,center[1],45));
    assert(m[12]<-0.84f);
    assert(stance_camber_rotate_car(m,center[0],center[3],0,-20,1));
}
static void airride_test(void){
    AirrideLogic a={0};a.drop_cm=3;
    assert((airride_logic_step(&a,1,0,1,1,1000)&1)!=0);
    assert(a.active);
    for(uint64_t t=1020;t<3200;t+=20)airride_logic_step(&a,0,0,1,1,t);
    assert(a.current_mm==30);
    assert((airride_logic_step(&a,0,0,0,1,3220)&4)!=0);
    assert(!a.active);
}
int main(void){lifecycle_test();profile_test();photo_test();airride_test();puts("PASS: lifecycle/profile/geometry/photo-airride (4 suites)");return 0;}
