/* Regression: no imported Interlocked routines; matching API semantics. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "stance_atomic_intrinsics.h"
int main(void){
    volatile LONG x=0;
    assert(sa_cmpxchg32(&x,3,0)==0 && x==3);
    assert(sa_cmpxchg32(&x,5,0)==3 && x==3);
    assert(sa_xchg32(&x,6)==3 && x==6);
    assert(sa_inc32(&x)==7 && x==7);
    assert(sa_dec32(&x)==6 && x==6);
    volatile LONGLONG y=0;
    assert(sa_cmpxchg64(&y,7,0)==0 && y==7);
    assert(sa_cmpxchg64(&y,9,0)==7 && y==7);
    assert(sa_xchg64(&y,11)==7 && y==11);
    int a=1,b=2;
    PVOID volatile ptr=&a;
    assert(sa_cmpxchgptr(&ptr,&b,&a)==&a && ptr==&b);
    assert(sa_cmpxchgptr(&ptr,&a,&a)==&b && ptr==&b);
    assert(sa_xchgptr(&ptr,&a)==&b && ptr==&a);
    puts("PASS: native atomic wrapper semantics (32/64/pointer, CAS/exchange/increment/decrement)");
    return 0;
}
