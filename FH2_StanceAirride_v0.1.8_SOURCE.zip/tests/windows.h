#ifndef FH2_PLATFORM_TEST_WIN_H
#define FH2_PLATFORM_TEST_WIN_H
#include <stddef.h>
#include <stdint.h>
#include <wchar.h>
typedef void *HANDLE,*LPVOID,*HWND,*PVOID;
typedef unsigned long DWORD;
typedef long LONG;
typedef long long LONGLONG;
#define WINAPI
#define MEM_COMMIT 0x1000
#define PAGE_GUARD 0x100
#define PAGE_NOACCESS 0x01
#define PAGE_READONLY 0x02
#define PAGE_READWRITE 0x04
#define PAGE_WRITECOPY 0x08
#define PAGE_EXECUTE_READ 0x20
#define PAGE_EXECUTE_READWRITE 0x40
#define PAGE_EXECUTE_WRITECOPY 0x80
#define VK_OEM_MINUS 0xbd
#define VK_SUBTRACT 0x6d
#define VK_F8 0x77
#define MAX_PATH 260
typedef struct {void *BaseAddress;void *AllocationBase;DWORD AllocationProtect;size_t RegionSize;DWORD State;DWORD Protect;DWORD Type;} MEMORY_BASIC_INFORMATION;
size_t VirtualQuery(const void*,MEMORY_BASIC_INFORMATION*,size_t);
uint64_t GetTickCount64(void);
HWND GetForegroundWindow(void);
DWORD GetWindowThreadProcessId(HWND,DWORD*);
DWORD GetCurrentProcessId(void);
int16_t GetAsyncKeyState(int);
int16_t VkKeyScanW(wchar_t);
DWORD GetPrivateProfileStringW(const wchar_t*,const wchar_t*,const wchar_t*,wchar_t*,DWORD,const wchar_t*);
int WritePrivateProfileStringW(const wchar_t*,const wchar_t*,const wchar_t*,const wchar_t*);
int GetPrivateProfileIntW(const wchar_t*,const wchar_t*,int,const wchar_t*);
HANDLE CreateThread(void*,size_t,DWORD(*)(LPVOID),void*,DWORD,DWORD*);
int CloseHandle(HANDLE);
LONG InterlockedCompareExchange(volatile LONG*,LONG,LONG);
LONGLONG InterlockedCompareExchange64(volatile LONGLONG*,LONGLONG,LONGLONG);
LONGLONG InterlockedExchange64(volatile LONGLONG*,LONGLONG);
LONG InterlockedIncrement(volatile LONG*);
LONG InterlockedDecrement(volatile LONG*);
LONG InterlockedExchange(volatile LONG*,LONG);
PVOID InterlockedCompareExchangePointer(PVOID volatile*,PVOID,PVOID);
PVOID InterlockedExchangePointer(PVOID volatile*,PVOID);
#endif
