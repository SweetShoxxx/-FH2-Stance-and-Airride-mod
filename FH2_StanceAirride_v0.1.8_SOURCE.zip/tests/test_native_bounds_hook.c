/* Local test of actual Windows loader hook with a fake game row loader. */
#include <assert.h>
#include <stdio.h>
#include <stddef.h>
#include <stdint.h>
#include <string.h>
#include "windows.h"
size_t VirtualQuery(const void *p,MEMORY_BASIC_INFORMATION *m,size_t sz){
    if(!p||!m||sz<sizeof(*m))return 0;
    uintptr_t base=(uintptr_t)p&~(uintptr_t)0xfffu;
    *m=(MEMORY_BASIC_INFORMATION){0};
    m->BaseAddress=(void*)base;m->RegionSize=0x2000;
    m->State=MEM_COMMIT;m->Protect=PAGE_READWRITE;
    return sizeof(*m);
}
uint64_t GetTickCount64(void){return 5000;}
LONG InterlockedCompareExchange(volatile LONG *p,LONG v,LONG cmp){return __sync_val_compare_and_swap(p,cmp,v);}
LONG InterlockedExchange(volatile LONG *p,LONG v){return __sync_lock_test_and_set(p,v);}
LONG InterlockedIncrement(volatile LONG *p){return __sync_add_and_fetch(p,1);}
LONG InterlockedDecrement(volatile LONG *p){return __sync_sub_and_fetch(p,1);}
LONGLONG InterlockedCompareExchange64(volatile LONGLONG *p,LONGLONG v,LONGLONG cmp){return __sync_val_compare_and_swap(p,cmp,v);}
LONGLONG InterlockedExchange64(volatile LONGLONG *p,LONGLONG v){return __sync_lock_test_and_set(p,v);}
PVOID InterlockedCompareExchangePointer(PVOID volatile *p,PVOID v,PVOID cmp){return __sync_val_compare_and_swap(p,cmp,v);}
PVOID InterlockedExchangePointer(PVOID volatile *p,PVOID v){return __sync_lock_test_and_set(p,v);}
#include "../src/stance_spring_bounds_platform.c"
static int calls=0,logs=0;
static void logger(FH2Mod *m,const char *s){(void)m;(void)s;logs++;}
static float raw[5]={0.1825f,0.1734f,0.2198f,0.1368f,0.1665f};
static uintptr_t loader(void *out,void *metadata,void *reader){
    (void)metadata;(void)reader;calls++;
    memcpy((unsigned char*)out+0x0c,raw,sizeof raw);
    return 1;
}
static float readat(const unsigned char *out,int ofs){float f;memcpy(&f,out+ofs,4);return f;}
static void nearf(float a,float b){assert(a>b-0.00011f&&a<b+0.00011f);}
int main(void){
    FH2ModApi mock={0};mock.log=logger;
    platform=&mock;owner=(FH2Mod*)1;
    unsigned char out[128]={0};
    /* v5.65 GLOBAL behavior: even the first pre-UI loader call is expanded. */
    row_hook(0,loader,out,NULL,NULL);
    nearf(readat(out,0x10),0.1434f);
    nearf(readat(out,0x14),0.2698f);
    nearf(readat(out,0x0c),0.1825f);
    assert(changed[0]==1&&ui_page_count==0);
    /* Every subsequent native row can be expanded, not one-shot. */
    row_hook(0,loader,out,NULL,NULL);
    row_hook(1,loader,out,NULL,NULL);
    assert(changed[0]==2&&changed[1]==1);
    assert(calls==3);
    /* v5.60 correction: a stock default at the MIN bound is eligible. */
    raw[0]=0.2000f;raw[1]=0.2000f;raw[2]=0.2400f;
    raw[3]=0.1500f;raw[4]=0.0900f;
    row_hook(0,loader,out,NULL,NULL);
    nearf(readat(out,0x10),0.1700f);
    nearf(readat(out,0x14),0.2850f); /* ceiling clamps requested +5cm */
    assert(clamped[0]==1);
    /* Stock default exactly at both bounds: extend both directions. */
    raw[2]=raw[1];
    row_hook(1,loader,out,NULL,NULL);
    nearf(readat(out,0x10),0.1700f);
    nearf(readat(out,0x14),0.2500f);
    /* Reject clearly corrupt and inconsistent data. */
    raw[3]=0.f;
    row_hook(0,loader,out,NULL,NULL);
    assert(changed[0]==3);
    sap_bounds_observe_player((void*)0x5000,(void*)0x7000,1296);
    sap_bounds_note_tuning_page(1296);
    assert(ui_page_count==1&&logs>0);
    printf("PASS: v565 loader modifies early+later eligible rows, supports boundary defaults, clamps, rejects corrupt data (%d calls)\n",calls);
    return 0;
}
