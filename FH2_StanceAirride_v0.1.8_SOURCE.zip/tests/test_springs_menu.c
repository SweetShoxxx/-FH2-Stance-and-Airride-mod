#include <assert.h>
#include <stdio.h>
#include <stddef.h>
#include <string.h>
#include "stance_springs_preview.h"
static const char orig[]=
 "<Screen x:Class=\"ForzaUI.Scenes.Anthem.A_TuningOptions\">\n"
 "<local:CommonListBox x:Name=\"StackPanel_5_Springs\">\n"
 "<Slider x:Name=\"OriginalFrontRideHeight\"/>\n"
 "<Slider x:Name=\"OriginalRearRideHeight\"/>\n"
 "</local:CommonListBox></Screen>";
int main(void){
 char out[20000];int initial[6]={-20,-20,-150,-150,45,48};
 size_t n=stance_springs_preview_xaml(orig,strlen(orig),out,sizeof out,initial,1535,1,1);
 assert(n>strlen(orig));
 assert(strstr(out,"OriginalFrontRideHeight"));
 assert(strstr(out,"OriginalRearRideHeight"));
 assert(strstr(out,"StanceFrontCamber"));
 assert(strstr(out,"Stance (only optical)"));
 assert(strstr(out,"Car ID: 1535"));
 assert(!strstr(out,"Mercedes BETA"));
 assert(!strstr(out,"Camber (deg)"));
 assert(strstr(out,"Front Camber"));
 assert(strstr(out,"Rear Camber"));
 assert(strstr(out,"Front Spacers (mm/side)"));
 assert(strstr(out,"Rear Spacers (mm/side)"));
 assert(strstr(out,"Photo Airride Drop (cm)"));
 assert(!strstr(out,"Sturz vorne"));
 assert(strstr(out,"StanceRearCamber"));
 assert(strstr(out,"StanceFrontTrack"));
 assert(strstr(out,"StanceRearTrack"));
 assert(strstr(out,"AirridePhotoDepthCm"));
 assert(!stance_springs_preview_xaml(out,n,out,sizeof out,initial,1535,1,1));
 assert(stance_springs_preview_xaml(orig,strlen(orig),out,sizeof out,initial,1104,0,1)>0);
 assert(!strstr(out,"AirridePhotoDepthCm"));
 assert(stance_springs_preview_xaml(orig,strlen(orig),out,sizeof out,initial,1104,1,1)>0);
 assert(strstr(out,"AirridePhotoDepthCm"));
 assert(stance_springs_preview_xaml(orig,strlen(orig),out,sizeof out,initial,1535,1,0)>0);
 assert(strstr(out,"Stance (only optical)"));
 assert(!strstr(out,"Car ID:"));
 assert(!strstr(out,"unknown"));
 assert(stance_springs_preview_xaml(orig,strlen(orig),out,sizeof out,initial,0,1,1)>0);
 assert(!strstr(out,"Car ID:"));
 assert(!stance_springs_preview_xaml("abc",3,out,sizeof out,initial,1535,1,1));
 puts("PASS: user-requested menu labels, verified Car ID only, spring controls, photo depth and repeat protection");
 return 0;
}
