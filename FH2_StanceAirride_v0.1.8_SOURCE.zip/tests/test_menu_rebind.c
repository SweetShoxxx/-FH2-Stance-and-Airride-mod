/* Lightweight host test for new vehicle binding on every UI getter/setter.
   Calls code directly so stale model_id behavior is exercised, no game DLL. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include "../src/stance_menu_platform.c"
static uint32_t wanted;
static int attempts;
static int allowed=1;
static int verify_player(void){
    attempts++;
    if(!allowed)return 0;
    StanceProfileValues neutral={0};
    sap_menu_select(wanted,&neutral,1);
    return 1;
}
/* Windows stubs needed by the active path of this test only. */
LONG InterlockedCompareExchange(volatile LONG *p,LONG set,LONG comparand){
    LONG old=*p;if(old==comparand)*p=set;return old;
}
LONG InterlockedExchange(volatile LONG *p,LONG val){LONG old=*p;*p=val;return old;}
int GetPrivateProfileIntW(const wchar_t *s,const wchar_t *k,int fallback,const wchar_t *f){
    (void)s;(void)k;(void)f;return fallback;
}
LONG InterlockedIncrement(volatile LONG *p){return ++*p;}
size_t VirtualQuery(const void *p,MEMORY_BASIC_INFORMATION *info,size_t len){
    (void)p;(void)info;(void)len;return 0;
}
int WritePrivateProfileStringW(const wchar_t *a,const wchar_t *b,
             const wchar_t *v,const wchar_t *f){
    (void)a;(void)b;(void)v;(void)f;return 1;
}
int main(void){
    /* Old owned car was known, then a different player car is selected. */
    sap_menu_set_player_sync(verify_player);
    StanceProfileValues neutral={0};
    sap_menu_select(1535,&neutral,1);
    assert(model_id==1535);
    wanted=1104;
    void *result=(void*)0x1234;
    assert(get_prop(&result,&properties[0],NULL)==&result);
    assert(model_id==1104 && attempts==1);
    /* Even without a new native CarUpdate, clicking must verify again. */
    wanted=2200;
    set_prop(&properties[0],(void*)0x1,(void*)0x1);
    assert(model_id==2200 && attempts==2);
    /* While player identity is unavailable, the previous cached model may
       still display, but setters must not write to its profile. */
    allowed=0;wanted=900;
    set_prop(&properties[0],(void*)0x1,(void*)0x1);
    assert(model_id==2200 && attempts==3);
    printf("PASS: updated model before menu getter/setter, unverified player blocked\n");
    return 0;
}
