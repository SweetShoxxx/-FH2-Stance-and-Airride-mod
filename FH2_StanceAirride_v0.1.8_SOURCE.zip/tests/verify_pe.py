#!/usr/bin/env python3
"""Offline signature sanity checks against user-provided FH2 1.0.0.64 EXE."""
import sys, struct, hashlib
from pathlib import Path
p=Path(sys.argv[1]).read_bytes()
assert p[:2]==b'MZ';e=struct.unpack_from('<I',p,0x3c)[0]
assert p[e:e+4]==b'PE\0\0'
n,=struct.unpack_from('<H',p,e+6);op,=struct.unpack_from('<H',p,e+20)
sects=[]
for i in range(n):
 h=p[e+24+op+40*i:e+24+op+40*(i+1)]
 virt,sz,raw=struct.unpack_from('<III',h,12)
 sects.append((virt,sz,raw))
def find(addr,needle):
 for virt,sz,raw in sects:
  if virt<=addr<virt+sz:
   assert p[raw+addr-virt:raw+addr-virt+len(needle)]==needle,hex(addr)
   return
 raise AssertionError(hex(addr))
assert hashlib.sha256(p).hexdigest()=="3ec04c6163fb5614e3d351ba0570d39b846041a257715d6340eceb03ccb7f0a3"
checks={0x2a9400:'488bc44889581857',0x138e3e0:'4889542410555356',
0x13b7810:'4c8bdc41564883ec',0x13af06c:'e88f97e0ff',
0x13af086:'e8b5a6e0ff',0x137c6b2:'e8297f3800',
0xaabec0:'4883ec18488b4138', 0xe98e10:'40534881ecd0000000'}
for addr,hexbytes in checks.items():find(addr,bytes.fromhex(hexbytes))
print('PASS: game EXE SHA256 and 6 optical + 2 Springs UI signatures verified')
