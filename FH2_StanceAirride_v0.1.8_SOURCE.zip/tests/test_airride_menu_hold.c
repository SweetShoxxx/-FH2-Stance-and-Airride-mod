#include <assert.h>
#include <stdio.h>
#include "stance_airride_context.h"
int main(void){
    AirrideLogic s={0};s.drop_cm=4;
    assert(airride_logic_step(&s,1,0,1,1,1000)&1u);
    for(uint64_t i=1020;i<=3020;i+=20)airride_logic_step(&s,0,0,1,1,i);
    assert(s.active==1&&s.current_mm==40);
    /* Spring tuning menu enters/leaves paused context repeatedly. */
    stance_airride_hold_during_menu(&s,3100);
    stance_airride_hold_during_menu(&s,103100);
    assert(s.active==1&&s.current_mm==40&&s.last_tick==103100);
    airride_logic_step(&s,0,0,1,1,103120);
    assert(s.active==1&&s.current_mm==40);
    /* New scene for same player does not reset the actuator. */
    stance_airride_hold_during_menu(&s,103150);
    assert(s.active==1&&s.current_mm==40);
    /* Actual car switch DOES reset airride, keeps depth preference. */
    stance_airride_reset_for_new_car(&s);
    assert(s.active==0&&s.current_mm==0&&s.drop_cm==4);
    puts("PASS: photo airride remains lowered across pause/menu/scene rebind; resets on actual car change");
}
