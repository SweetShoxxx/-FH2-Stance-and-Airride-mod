#include <assert.h>
#include <stdio.h>
#include "stance_generic_bounds_v556.h"
#include "stance_spring_gate.h"
int main(void){
 const float h[5]={0.1825f,0.1734f,0.2198f,0.1368f,0.1665f};
 float lo=0,hi=0;int a=0,b=0;
 assert(fh2_v556_calculate(h,&lo,&hi,&a,&b));
 assert(a==FH2_BOUND_FULL && b==FH2_BOUND_FULL);
 assert(lo>0.14339f&&lo<0.14341f);
 assert(hi>0.26979f&&hi<0.26981f);
 assert(sap_spring_gate_eligible(1535,1535,5000,5100,10000));
 assert(!sap_spring_gate_eligible(1103,1535,5000,5100,10000));
 assert(!sap_spring_gate_eligible(1535,1535,5000,15001,10000));
 assert(!sap_spring_gate_eligible(1535,1535,0,100,10000));
 const float c[5]={0.20f,0.18f,0.25f,0.165f,0.07f};
 assert(fh2_v556_calculate(c,&lo,&hi,&a,&b));
 assert(a==FH2_BOUND_CLAMPED);
 puts("PASS: native -3cm/+5cm bounds and tuning-page model/time gate");
 return 0;
}
