@echo off
setlocal EnableExtensions
cd /d "%~dp0"
set "ZIG=%~1"
if not defined ZIG set "ZIG=zig"
if not "%~1"=="" if not exist "%ZIG%" (
 echo ERROR: Drop Zig 0.15.2 zig.exe onto this batch file or use zig in PATH.
 exit /b 1
)
if not exist dist mkdir dist
"%ZIG%" cc -target x86_64-windows-gnu -std=c11 -O2 -shared -ffreestanding -fno-builtin -fno-stack-protector -Iinclude -Ivendor src\StanceAirride.c src\stance_menu_platform.c src\stance_spring_bounds_platform.c vendor\stance_profile_values.c vendor\stance_springs_preview.c -luser32 -lkernel32 -o dist\StanceAirride.dll
if errorlevel 1 (
 echo BUILD FAILED. No installation ZIP created.
 exit /b 1
)
python PACK_RELEASE.py "dist\StanceAirride.dll"
if errorlevel 1 (
 echo BUILD SUCCEEDED, but packaging FAILED.
 exit /b 1
)
echo BUILD COMPLETE! Standalone install zip is in dist.
endlocal
