# v0.1.8 English menu – final text cleanup

This build is based on the working v0.1.8 (v5.65 Legacy Springs) code and the previous English-menu source. Only the injected Springs menu UI text and the visibility rule for the model ID are changed. All physics/airride/camber math/profile storage/limits are untouched.

* Heading: `Stance (only optical)` for every car. No `Mercedes BETA Test` or car-dependent beta header.
* Sliders: `Front Camber`, `Rear Camber` (no `(deg)` suffix). `Rear Camber` is the correct English spelling.
* Model indicator: `Car ID: <number>` is rendered only when the current player car was verified during this exact menu resource load and the ID is nonzero. It is omitted completely when identity validation fails or the ID is missing. No `Car model: unknown` placeholder.
* Front/Rear Spacers and Photo Airride Drop labels stay English as before.
* Original localized Forza menu entries remain the game's own responsibility.

Install: close Azimuth, back up `D:\xboxone\fh2-mods\StanceAirride.dll`, extract the installation ZIP into `D:\xboxone` and replace only `fh2-mods\StanceAirride.dll`.

This is a Windows-x64 plugin DLL. Local unit tests and PE export/import checks are provided; the altered UI has not been tested in-game yet.
